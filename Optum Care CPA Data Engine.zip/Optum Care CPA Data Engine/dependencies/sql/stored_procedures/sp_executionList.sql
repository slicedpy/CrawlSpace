GO
EXEC dbo.GenerateAdjustmentReport @start_date='2018-06-01',@end_date='2018-06-12',@practice_id='0001'
GO
SELECT * FROM GenerateAdjustmentReportTempTable

GO
EXEC dbo.GenerateChargeReport @start_date='2018-06-01',@end_date='2018-06-12',@practice_id='0001'
GO
SELECT * FROM GenerateChargeReportTempTable

GO
[dbo].[GeneratePaymentReport] @start_date='2018-06-01',@end_date='2018-06-12',@practice_id='0001'
GO
SELECT * FROM GeneratePaymentReportTempTable