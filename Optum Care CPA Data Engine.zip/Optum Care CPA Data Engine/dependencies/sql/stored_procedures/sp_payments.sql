USE [NGProd]
GO
/****** Object:  StoredProcedure [dbo].[GeneratePaymentReport]    Script Date: 6/13/2018 6:22:12 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER PROCEDURE [dbo].[GeneratePaymentReport] @start_date date,@end_date date, @practice_id char(4)

AS

IF (EXISTS (SELECT * FROM INFORMATION_SCHEMA.tables where  upper(table_name)='GeneratePaymentReportTempTable'))
BEGIN DROP TABLE dbo.GeneratePaymentReportTempTable; END

CREATE TABLE GeneratePaymentReportTempTable (
	practice_id CHAR(4) NOT NULL
	,trans_id UNIQUEIDENTIFIER NULL
	,guar_id UNIQUEIDENTIFIER NULL
	,practice_name VARCHAR(40) NULL
	,location_id UNIQUEIDENTIFIER NULL
	,location_name VARCHAR(100) NULL
	,location_subgrouping1_id UNIQUEIDENTIFIER NULL
	,location_subgrouping2_id UNIQUEIDENTIFIER NULL
	,location_subgrouping1_desc VARCHAR(100) NULL
	,location_subgrouping2_desc VARCHAR(100) NULL
	,post_date CHAR(8) NULL
	,post_ind CHAR(1) NULL
	,source_type CHAR(1) NULL
	,source_type_desc VARCHAR(200) NULL
	,batch_date CHAR(8) NULL
	,batch_nbr CHAR(4) NULL
	,batch_description VARCHAR(80) NULL
	,tracking_desc_40 VARCHAR(80) NULL
	,source_id UNIQUEIDENTIFIER NOT NULL
	,source_nbr NUMERIC NULL
	,enc_nbr NUMERIC NULL
	,NAME VARCHAR(150) NULL
	,person_id UNIQUEIDENTIFIER NULL
	,insured_person_id UNIQUEIDENTIFIER NULL
	,person_payer_id UNIQUEIDENTIFIER NULL
	,insured_last_name VARCHAR(60) NULL
	,insured_first_name VARCHAR(60) NULL
	,insured_middle_name VARCHAR(25) NULL
	,charge_amt NUMERIC(19, 2) NULL
	,approved_amt NUMERIC(19, 2) NULL
	,refer_provider_id UNIQUEIDENTIFIER NULL
	,refer_name VARCHAR(78) NULL
	,chg_refer_id UNIQUEIDENTIFIER NULL
	,chg_refer_name VARCHAR(78) NULL
	,tran_date DATETIME NULL
	,tran_code_id UNIQUEIDENTIFIER NULL
	,tran_amt NUMERIC(19, 2) NULL
	,source CHAR(1) NULL
	,payer_id UNIQUEIDENTIFIER NULL
	,payer_name VARCHAR(40) NULL
	,financial_class UNIQUEIDENTIFIER NULL
	,financial_class_desc VARCHAR(100) NULL
	,rendering_provider_id UNIQUEIDENTIFIER NULL
	,attend_first_name VARCHAR(25) NULL
	,attend_middle_name VARCHAR(25) NULL
	,attend_last_name VARCHAR(25) NULL
	,create_timestamp DATETIME NULL
	,created_by INT NULL
	,modify_timestamp DATETIME NULL
	,modified_by INT NULL
	,closing_date CHAR(8) NULL
	,admit_provider_id UNIQUEIDENTIFIER NULL
	,admit_provider_name VARCHAR(78) NULL
	,consult1_provider_id UNIQUEIDENTIFIER NULL
	,consult1_provider_name VARCHAR(78) NULL
	,consult2_provider_id UNIQUEIDENTIFIER NULL
	,consult2_provider_name VARCHAR(78) NULL
	,unapplied_trans_y_n CHAR(1) NULL
	,invoice_desc_1 VARCHAR(120) NULL
	,invoice_desc_2 VARCHAR(120) NULL
	,trans_status CHAR(1) NULL
	,trans_status_desc VARCHAR(200) NULL
	,reason_codes CHAR(1000) NULL
	,service_item_lib_id UNIQUEIDENTIFIER NULL
	,service_item_id VARCHAR(12) NULL
	,service_item_description VARCHAR(80) NULL
	,department UNIQUEIDENTIFIER NULL
	,department_desc VARCHAR(100) NULL
	,modality UNIQUEIDENTIFIER NULL
	,modality_desc VARCHAR(100) NULL
	,component CHAR(1) NULL
	,component_desc VARCHAR(200) NULL
	,revenue_code CHAR(4) NULL
	,begin_date_of_service CHAR(8) NULL
	,quantity SMALLINT NULL
	,unit_price NUMERIC(19, 2) NULL
	,place_of_service CHAR(2) NULL
	,place_of_service_desc VARCHAR(200) NULL
	,rvu1 FLOAT NULL
	,rvu1_total FLOAT NULL
	,rvu2 FLOAT NULL
	,rvu2_total FLOAT NULL
	,rvu3 FLOAT NULL
	,rvu3_total FLOAT NULL
	,rvu4 FLOAT NULL
	,rvu4_total FLOAT NULL
	,rvu5 FLOAT NULL
	,rvu5_total FLOAT NULL
	,rvu6 FLOAT NULL
	,rvu6_total FLOAT NULL
	,rvu7 FLOAT NULL
	,rvu7_total FLOAT NULL
	,rvu8 FLOAT NULL
	,rvu8_total FLOAT NULL
	,midlevel_id UNIQUEIDENTIFIER NULL
	,mid_last_name VARCHAR(25) NULL
	,mid_first_name VARCHAR(25) NULL
	,mid_middle_name VARCHAR(25) NULL
	,td_notes VARCHAR(255) NULL
	,ch_notes VARCHAR(255) NULL
	,aftercare_days INTEGER NULL
	,supervisor_provider_id UNIQUEIDENTIFIER NULL
	,supervisor_provider_name VARCHAR(78) NULL
	,cob1_amt NUMERIC(19, 2) NULL
	,cob2_amt NUMERIC(19, 2) NULL
	,cob3_amt NUMERIC(19, 2) NULL
	,pat_amt NUMERIC(19, 2) NULL
	,final_bill_date CHAR(8) NULL
	,last_bill_date CHAR(8) NULL
	,cpt4_code_id VARCHAR(13) NULL
	,cpt4_description VARCHAR(50) NULL
	,library_desc_50 VARCHAR(50) NULL
	,icd9cm_code_id VARCHAR(10) NULL
	,icd9cm_code_id_2 VARCHAR(10) NULL
	,icd9cm_code_id_3 VARCHAR(10) NULL
	,icd9cm_code_id_4 VARCHAR(10) NULL
	,icd9cm_code_desc VARCHAR(255) NULL
	,icd9cm_code_desc_2 VARCHAR(255) NULL
	,icd9cm_code_desc_3 VARCHAR(255) NULL
	,icd9cm_code_desc_4 VARCHAR(255) NULL
	,date_of_birth CHAR(8) NULL
	,patient_age CHAR(8) NULL
	,patient_age_unformatted INTEGER NULL
	,patient_age_dos_unformatted INTEGER NULL
	,city VARCHAR(35) NULL
	,address_line_1 VARCHAR(55)
	,address_line_2 VARCHAR(55)
	,zip CHAR(9) NULL
	,country_id UNIQUEIDENTIFIER
	,county_id UNIQUEIDENTIFIER
	,county_desc VARCHAR(100) NULL
	,sex CHAR(1) NULL
	,sex_desc VARCHAR(30) NULL
	,override_closing_date CHAR(8) NULL
	,revenue_description VARCHAR(80) NULL
	,value_code CHAR(2) NULL
	,occur_code CHAR(2) NULL
	,patient_type_id UNIQUEIDENTIFIER NULL
	,patient_type_desc VARCHAR(100) NULL
	,provider_subgrp1_id UNIQUEIDENTIFIER NULL
	,provider_subgrp1_desc VARCHAR(100) NULL
	,provider_subgrp2_id UNIQUEIDENTIFIER NULL
	,provider_subgrp2_desc VARCHAR(100) NULL
	,deductible_amt NUMERIC(19, 2) NULL
	,ud_demo1_id UNIQUEIDENTIFIER NULL
	,ud_demo1 VARCHAR(100) NULL
	,ud_demo2_id UNIQUEIDENTIFIER NULL
	,ud_demo2 VARCHAR(100) NULL
	,ud_demo3_id UNIQUEIDENTIFIER NULL
	,ud_demo3 VARCHAR(100) NULL
	,ud_demo4_id UNIQUEIDENTIFIER NULL
	,ud_demo4 VARCHAR(100) NULL
	,ud_demo5_id UNIQUEIDENTIFIER NULL
	,ud_demo5 VARCHAR(100) NULL
	,ud_demo6_id UNIQUEIDENTIFIER NULL
	,ud_demo6 VARCHAR(100) NULL
	,ud_demo7_id UNIQUEIDENTIFIER NULL
	,ud_demo7 VARCHAR(100) NULL
	,ud_demo8_id UNIQUEIDENTIFIER NULL
	,ud_demo8 VARCHAR(100) NULL
	,ud_demo9_id UNIQUEIDENTIFIER NULL
	,ud_demo9 VARCHAR(100) NULL
	,ud_demo10_id UNIQUEIDENTIFIER NULL
	,ud_demo10 VARCHAR(100) NULL
	,ud_demo11_id UNIQUEIDENTIFIER NULL
	,ud_demo11 VARCHAR(100) NULL
	,ud_demo12_id UNIQUEIDENTIFIER NULL
	,ud_demo12 VARCHAR(100) NULL
	,ud_demo13_id UNIQUEIDENTIFIER NULL
	,ud_demo13 VARCHAR(100) NULL
	,ud_demo14_id UNIQUEIDENTIFIER NULL
	,ud_demo14 VARCHAR(100) NULL
	,enc_rendering_id UNIQUEIDENTIFIER NULL
	,enc_rendering_name VARCHAR(78) NULL
	,baddebt_amt NUMERIC(19, 2) NULL
	,self_less_baddebt_amt NUMERIC(19, 2) NULL
	,aneth_base_unit INT NULL
	,aneth_start_time CHAR(4) NULL
	,aneth_stop_time CHAR(4) NULL
	,aneth_total_time CHAR(4) NULL
	,aneth_alt_code CHAR(9) NULL
	,charge_id UNIQUEIDENTIFIER NOT NULL
	,detail_id UNIQUEIDENTIFIER
	,detail_type CHAR(1) NULL
	,payer_subgrouping1_id UNIQUEIDENTIFIER NULL
	,payer_subgrouping2_id UNIQUEIDENTIFIER NULL
	,payer_subgrouping1_desc VARCHAR(100) NULL
	,payer_subgrouping2_desc VARCHAR(100) NULL
	,allowed_amt NUMERIC(19, 2) NULL
	,facility_location_id UNIQUEIDENTIFIER NULL
	,facility_name VARCHAR(40) NULL
	,outsource_ind CHAR(1) NULL
	,outsource_date CHAR(8) NULL
	,outsource_agency_id UNIQUEIDENTIFIER
	,outsource_agency_desc VARCHAR(40) NULL
	,fqhc_enc_ind CHAR(1) NULL
	,person_nbr CHAR(12) NULL
	,pat_prov_name_1 VARCHAR(75)
	,pat_prov_name_2 VARCHAR(75)
	,pat_prov_name_3 VARCHAR(75)
	,pat_prov_name_4 VARCHAR(75)
	,pat_prov_name_5 VARCHAR(75)
	,pat_prov_name_6 VARCHAR(75)
	,pat_prov_name_7 VARCHAR(75)
	,pat_prov_name_8 VARCHAR(75)
	,pat_prov_name_9 VARCHAR(75)
	,pat_prov_name_10 VARCHAR(75)
	,pat_prov_name_11 VARCHAR(75)
	,pat_prov_name_12 VARCHAR(75)
	,mrkt_plan_id UNIQUEIDENTIFIER NULL
	,mrkt_source_id UNIQUEIDENTIFIER NULL
	,mrkt_source_type INTEGER NULL
	,mrkt_comments VARCHAR(255) NULL
	,mrkt_details VARCHAR(255)
	,mrkt_plan UNIQUEIDENTIFIER NULL
	,marketing_desc VARCHAR(40) NULL
	,marketing_plan_desc VARCHAR(100) NULL
	,med_rec_nbr CHAR(12) NULL
	,diag1_riskadj_ind CHAR(1) NULL
	,diag2_riskadj_ind CHAR(1) NULL
	,diag3_riskadj_ind CHAR(1) NULL
	,diag4_riskadj_ind CHAR(1) NULL
	,sliding_fee_id UNIQUEIDENTIFIER
	,sliding_fee_detail_id UNIQUEIDENTIFIER
	,sliding_fee_sched_dtl_desc VARCHAR(80) NULL
	,hist_family_size_nbr INTEGER
	,hist_family_income NUMERIC(19, 2) NULL
	,family_size_nbr INTEGER
	,family_income NUMERIC(19, 2) NULL
	,percentage_discount INTEGER NULL
	,casemgt_case_id UNIQUEIDENTIFIER
	,case_num NUMERIC(12, 0) NULL
	,case_desc VARCHAR(255) NULL
	,case_sts VARCHAR(40) NULL
	,case_emp_id UNIQUEIDENTIFIER
	,case_emp_name VARCHAR(40) NULL
	,ins1_name VARCHAR(40) NULL
	,ins1_address1 VARCHAR(55) NULL
	,ins1_address2 VARCHAR(55) NULL
	,ins1_city VARCHAR(35) NULL
	,ins1_state CHAR(3) NULL
	,ins1_zip CHAR(9) NULL
	,ins1_contact VARCHAR(80) NULL
	,ins1_contact_phone CHAR(10) NULL
	,ins1_contact_ext CHAR(5) NULL
	,ins1_contact_fax CHAR(10) NULL
	,ins2_name VARCHAR(40) NULL
	,ins2_address1 VARCHAR(55) NULL
	,ins2_address2 VARCHAR(55) NULL
	,ins2_city VARCHAR(35) NULL
	,ins2_state CHAR(3) NULL
	,ins2_zip CHAR(9) NULL
	,ins2_contact VARCHAR(80) NULL
	,ins2_contact_phone CHAR(10) NULL
	,ins2_contact_ext CHAR(5) NULL
	,ins2_contact_fax CHAR(10) NULL
	,ins3_name VARCHAR(40) NULL
	,ins3_address1 VARCHAR(55) NULL
	,ins3_address2 VARCHAR(55) NULL
	,ins3_city VARCHAR(35) NULL
	,ins3_state CHAR(3) NULL
	,ins3_zip CHAR(9) NULL
	,ins3_contact VARCHAR(80) NULL
	,ins3_contact_phone CHAR(10) NULL
	,ins3_contact_ext CHAR(5) NULL
	,ins3_contact_fax CHAR(10) NULL
	,uds_homeless_status_id UNIQUEIDENTIFIER NULL
	,uds_homeless_status_desc VARCHAR(100) NULL
	,uds_migrant_worker_status_id UNIQUEIDENTIFIER NULL
	,uds_migrant_worker_status_desc VARCHAR(100) NULL
	,uds_language_barrier_id UNIQUEIDENTIFIER NULL
	,uds_language_barrier_desc VARCHAR(100) NULL
	,uds_primary_med_coverage_id UNIQUEIDENTIFIER NULL
	,uds_primary_med_coverage_desc VARCHAR(100) NULL
	,race_desc VARCHAR(255)
	,ethnicity_id UNIQUEIDENTIFIER NULL
	,ethnicity_desc VARCHAR(100) NULL
	,uds_tribal_affiliation_id UNIQUEIDENTIFIER NULL
	,uds_tribal_affiliation_desc VARCHAR(100) NULL
	,uds_blood_quantum_id UNIQUEIDENTIFIER NULL
	,uds_blood_quantum_desc VARCHAR(100) NULL
	,uds_school_hlth_ctr_id UNIQUEIDENTIFIER NULL
	,uds_school_hlth_ctr_desc VARCHAR(100)
	,uds_pub_hsng_pri_care_id UNIQUEIDENTIFIER NULL
	,uds_pub_hsng_pri_care_desc VARCHAR(100) NULL
	,uds_veteran_status CHAR(1) NULL
	,uds_veteran_status_desc VARCHAR(100) NULL
	,uds_consent_to_treat_ind CHAR(1) NULL
	,ent_batch_nbr CHAR(4) NULL
	,ent_batch_date CHAR(8) NULL
	,poverty_pct NUMERIC NULL
	,poverty_cat VARCHAR(20) NULL
	,uds_descendancy_id UNIQUEIDENTIFIER NULL
	,uds_descendancy_desc VARCHAR(100) NULL
	,uds_ihs_elig_status_id UNIQUEIDENTIFIER NULL
	,uds_ihs_elig_status_desc VARCHAR(100) NULL
	,uds_tribal_class_id UNIQUEIDENTIFIER NULL
	,uds_tribal_class_desc VARCHAR(100) NULL
	,uds_consent_to_treat_date CHAR(8) NULL
	,community_code_id UNIQUEIDENTIFIER NULL
	,community_code_desc VARCHAR(100)
	,enc_homeless_status_id UNIQUEIDENTIFIER
	,enc_homeless_status_desc VARCHAR(100) NULL
	,primary_dental_prov_id UNIQUEIDENTIFIER NULL
	,primary_dental_prov_name VARCHAR(75) NULL
	,cc_vendor_nbr VARCHAR(50) NULL
	,prim_enc_rate_sim VARCHAR(13) NULL
	,prim_enc_rate_amt NUMERIC(19, 2) NULL
	,sec_enc_rate_sim VARCHAR(13) NULL
	,sec_enc_rate_amt NUMERIC(19, 2) NULL
	,ter_enc_rate_sim VARCHAR(13) NULL
	,ter_enc_rate_amt NUMERIC(19, 2) NULL
	,refused_to_report_ind CHAR(1) NULL
	,patient_age_in_months INTEGER NULL
	,patient_age_in_months_on_dos INTEGER NULL
	,cc_vendor_processor_name VARCHAR(50) NULL
	,merchant_id VARCHAR(50) NULL
	,icd_type VARCHAR(2) NULL
	,icd_type_2 VARCHAR(2) NULL
	,icd_type_3 VARCHAR(2) NULL
	,icd_type_4 VARCHAR(2) NULL
	,diagnosis_subgroup1_id VARCHAR(255) NULL
	,diagnosis_subgroup1 VARCHAR(255) NULL
	,diagnosis_subgroup1_id_2 VARCHAR(255) NULL
	,diagnosis_subgroup1_2 VARCHAR(255) NULL
	,diagnosis_subgroup1_id_3 VARCHAR(255) NULL
	,diagnosis_subgroup1_3 VARCHAR(255) NULL
	,diagnosis_subgroup1_id_4 VARCHAR(255) NULL
	,diagnosis_subgroup1_4 VARCHAR(255) NULL
	,diagnosis_subgroup2_id VARCHAR(255) NULL
	,diagnosis_subgroup2 VARCHAR(255) NULL
	,diagnosis_subgroup2_id_2 VARCHAR(255) NULL
	,diagnosis_subgroup2_2 VARCHAR(255) NULL
	,diagnosis_subgroup2_id_3 VARCHAR(255) NULL
	,diagnosis_subgroup2_3 VARCHAR(255) NULL
	,diagnosis_subgroup2_id_4 VARCHAR(255) NULL
	,diagnosis_subgroup2_4 VARCHAR(255) NULL
	,diag_cat_id VARCHAR(255) NULL
	,diag_cat VARCHAR(1000) NULL
	,diag_cat_id_2 VARCHAR(255) NULL
	,diag_cat_2 VARCHAR(1000) NULL
	,diag_cat_id_3 VARCHAR(255) NULL
	,diag_cat_3 VARCHAR(1000) NULL
	,diag_cat_id_4 VARCHAR(255) NULL
	,diag_cat_4 VARCHAR(1000) NULL
	,agency_id UNIQUEIDENTIFIER NULL
	,agency_description VARCHAR(40) NULL
	,transaction_notes VARCHAR(8000) NULL
	,contracted_payer_ind CHAR(1) NULL
	,sec_payer_ind CHAR(1) NULL
	,ter_payer_ind CHAR(1) NULL
	,refund_address_line1 VARCHAR(55) NULL
	,refund_address_line2 VARCHAR(55) NULL
	,refund_city VARCHAR(35) NULL
	,refund_state VARCHAR(3) NULL
	,refund_zip CHAR(9) NULL
	,refund_country_id UNIQUEIDENTIFIER NULL
	,refund_county_id UNIQUEIDENTIFIER NULL
	,refund_county_desc VARCHAR(100) NULL
	,resubmission_reference_nbr VARCHAR(50) NULL
	,rental_ind CHAR(1) NULL
	,trans_batch_category_id UNIQUEIDENTIFIER NULL
	,trans_batch_category VARCHAR(100) NULL
	,section_name VARCHAR(40) NULL
	,refund_to_name VARCHAR(50) NULL
	,refund_ud_field1 VARCHAR(50) NULL
	,refund_ud_field2 VARCHAR(50)
	,refund_ud_field3 VARCHAR(50)
	,refund_ud_field4 VARCHAR(50)
	,refund_ud_field5 VARCHAR(50) NULL
	,refund_ud_field6 VARCHAR(50)
	,refund_ud_field7 VARCHAR(50) NULL
	,refund_ud_field8 VARCHAR(50)
	,refund_ud_field9 VARCHAR(50)
	,refund_ud_field10 VARCHAR(50)
	);

INSERT INTO GeneratePaymentReportTempTable (
	practice_id
	,trans_id
	,location_id
	,post_date
	,post_ind
	,source_type
	,batch_date
	,batch_nbr
	,tracking_desc_40
	,source_id
	,person_id
	,insured_person_id
	,person_payer_id
	,charge_amt
	,approved_amt
	,tran_date
	,tran_code_id
	,tran_amt
	,source
	,payer_id
	,financial_class
	,rendering_provider_id
	,create_timestamp
	,created_by
	,modify_timestamp
	,modified_by
	,closing_date
	,unapplied_trans_y_n
	,invoice_desc_1
	,invoice_desc_2
	,trans_status
	,reason_codes
	,service_item_lib_id
	,service_item_id
	,begin_date_of_service
	,quantity
	,place_of_service
	,rvu1
	,rvu1_total
	,rvu2
	,rvu2_total
	,rvu3
	,rvu3_total
	,rvu4
	,rvu4_total
	,rvu5
	,rvu5_total
	,rvu6
	,rvu6_total
	,rvu7
	,rvu7_total
	,rvu8
	,rvu8_total
	,midlevel_id
	,td_notes
	,ch_notes
	,unit_price
	,cob1_amt
	,cob2_amt
	,cob3_amt
	,pat_amt
	,cpt4_code_id
	,icd9cm_code_id
	,icd9cm_code_id_2
	,icd9cm_code_id_3
	,icd9cm_code_id_4
	,icd9cm_code_desc
	,icd9cm_code_desc_2
	,icd9cm_code_desc_3
	,icd9cm_code_desc_4
	,override_closing_date
	,revenue_description
	,value_code
	,occur_code
	,deductible_amt
	,detail_id
	,detail_type
	,charge_id
	,chg_refer_id
	,chg_refer_name
	,payer_subgrouping1_id
	,payer_subgrouping2_id
	,allowed_amt
	,facility_location_id
	,outsource_ind
	,outsource_date
	,outsource_agency_id
	,batch_description
	,mrkt_plan_id
	,mrkt_source_id
	,mrkt_source_type
	,mrkt_comments
	,mrkt_details
	,ent_batch_nbr
	,ent_batch_date
	,prim_enc_rate_sim
	,prim_enc_rate_amt
	,sec_enc_rate_sim
	,sec_enc_rate_amt
	,ter_enc_rate_sim
	,ter_enc_rate_amt
	,transaction_notes
	,contracted_payer_ind
	,refund_address_line1
	,refund_address_line2
	,refund_city
	,refund_state
	,refund_zip
	,refund_country_id
	,refund_county_id
	,resubmission_reference_nbr
	,trans_batch_category_id
	,section_name
	,refund_to_name
	,refund_ud_field1
	,refund_ud_field2
	,refund_ud_field3
	,refund_ud_field4
	,refund_ud_field5
	,refund_ud_field6
	,refund_ud_field7
	,refund_ud_field8
	,refund_ud_field9
	,refund_ud_field10
	)
SELECT t.practice_id
	,t.trans_id
	,c.location_id
	,t.post_date
	,t.post_ind
	,t.source_type
	,t.batch_date
	,t.batch_nbr
	,t.tracking_desc_40
	,t.source_id
	,c.person_id
	,pe.cob1_insured_person_id
	,pe.cob1_person_payer_id
	,c.amt
	,t.approved_amt
	,t.tran_date
	,t.tran_code_id
	,td.paid_amt
	,t.source
	,pe.cob1_payer_id
	,pm.financial_class
	,c.rendering_id
	,t.create_timestamp
	,t.created_by
	,t.modify_timestamp
	,t.modified_by
	,t.closing_date
	,''
	,c.invoice_desc_1
	,c.invoice_desc_2
	,td.trans_status
	,td.reason_codes_display_only
	,c.service_item_lib_id
	,c.service_item_id
	,c.begin_date_of_service
	,c.quantity
	,c.place_of_service
	,0.0
	,0.0
	,0.0
	,0.0
	,0.0
	,0.0
	,0.0
	,0.0
	,0.0
	,0.0
	,0.0
	,0.0
	,0.0
	,0.0
	,0.0
	,0.0
	,c.midlevel_id
	,td.note
	,c.note
	,c.unit_price
	,cob1_amt
	,cob2_amt
	,cob3_amt
	,pat_amt
	,cpt4_code_id
	,c.icd9cm_code_id
	,c.icd9cm_code_id_2
	,c.icd9cm_code_id_3
	,c.icd9cm_code_id_4
	,icd9cm_code_desc
	,icd9cm_code_desc_2
	,icd9cm_code_desc_3
	,icd9cm_code_desc_4
	,t.override_closing_date
	,c.revenue_description
	,c.value_code
	,c.occur_code
	,td.deduct_amt
	,td.source_id
	,td.source_type
	,c.charge_id
	,c.referring_id
	,c.referring_name
	,payer_subgrouping1_id
	,payer_subgrouping2_id
	,allowed_amt
	,pe.facility_location_id
	,c.outsource_ind
	,c.outsource_date
	,td.outsource_agency_id
	,b.description
	,mrkt_plan_id
	,mrkt_source_id
	,mrkt_source_type
	,mrkt_comments
	,mrkt_details
	,b.ent_batch_nbr
	,b.ent_batch_date
	,pe.prim_enc_rate_sim
	,pe.prim_enc_rate_amt
	,pe.sec_enc_rate_sim
	,pe.sec_enc_rate_amt
	,pe.ter_enc_rate_sim
	,pe.ter_enc_rate_amt
	,t.transaction_notes
	,pm.contracted_payer_ind
	,t.refund_address_line1
	,t.refund_address_line2
	,t.refund_city
	,t.refund_state
	,t.refund_zip
	,t.refund_country_id
	,t.refund_county_id
	,t.resubmission_reference_nbr
	,b.trans_batch_category_id
	,CASE 
		WHEN c.STATUS IN (
				'B'
				,'U'
				,'H'
				,'R'
				)
			THEN 'Accounts Receivable'
		WHEN c.STATUS = 'A'
			THEN 'Bad Debt'
		WHEN c.STATUS = 'I'
			THEN 'In Progress'
		ELSE 'Accounts Receivable'
		END
	,t.refund_to_name
	,ve.ud_field1
	,ve.ud_field2
	,ve.ud_field3
	,ve.ud_field4
	,ve.ud_field5
	,ve.ud_field6
	,ve.ud_field7
	,ve.ud_field8
	,ve.ud_field9
	,ve.ud_field10
FROM transactions t
LEFT OUTER JOIN batches b ON t.batch_nbr = b.batch_nbr
	AND t.batch_date = b.batch_date
	AND t.practice_id = b.practice_id
LEFT OUTER JOIN vendor_ext ve ON (
		t.external_id1 = ve.vendor_ext_id
		AND t.external_id2 = ve.pay_to_code
		)
	,trans_detail td
	,charges c
	,patient_encounter pe
	,payer_mstr pm
WHERE td.trans_id = t.trans_id
	AND td.practice_id = t.practice_id
	AND td.charge_id = c.charge_id
	AND pe.practice_id = c.practice_id
	AND pe.enc_id = c.source_id
	AND t.post_ind = 'Y'
	AND t.type = 'C'
	AND pe.cob1_payer_id = pm.payer_id
	AND t.closing_date >=

@start_date
	AND t.closing_date <

dateadd(dd, 1, dateadd(dd, 1, @end_date))
	AND t.source_type IN (
		'V'
		,'I'
		,'A'
		,'B'
		)
	AND td.practice_id = @practice_id
	AND c.practice_id = @practice_id;

INSERT INTO GeneratePaymentReportTempTable (
	practice_id
	,trans_id
	,location_id
	,post_date
	,post_ind
	,source_type
	,batch_date
	,batch_nbr
	,tracking_desc_40
	,source_id
	,person_id
	,charge_amt
	,approved_amt
	,tran_date
	,tran_code_id
	,tran_amt
	,source
	,rendering_provider_id
	,create_timestamp
	,created_by
	,modify_timestamp
	,modified_by
	,closing_date
	,unapplied_trans_y_n
	,invoice_desc_1
	,invoice_desc_2
	,trans_status
	,reason_codes
	,service_item_lib_id
	,service_item_id
	,begin_date_of_service
	,quantity
	,place_of_service
	,rvu1
	,rvu1_total
	,rvu2
	,rvu2_total
	,rvu3
	,rvu3_total
	,rvu4
	,rvu4_total
	,rvu5
	,rvu5_total
	,rvu6
	,rvu6_total
	,rvu7
	,rvu7_total
	,rvu8
	,rvu8_total
	,midlevel_id
	,td_notes
	,ch_notes
	,unit_price
	,cob1_amt
	,cob2_amt
	,cob3_amt
	,pat_amt
	,cpt4_code_id
	,icd9cm_code_id
	,icd9cm_code_id_2
	,icd9cm_code_id_3
	,icd9cm_code_id_4
	,icd9cm_code_desc
	,icd9cm_code_desc_2
	,icd9cm_code_desc_3
	,icd9cm_code_desc_4
	,override_closing_date
	,revenue_description
	,value_code
	,occur_code
	,deductible_amt
	,detail_id
	,detail_type
	,charge_id
	,chg_refer_id
	,chg_refer_name
	,allowed_amt
	,facility_location_id
	,outsource_ind
	,outsource_date
	,outsource_agency_id
	,batch_description
	,mrkt_plan_id
	,mrkt_source_id
	,mrkt_source_type
	,mrkt_comments
	,mrkt_details
	,ent_batch_nbr
	,ent_batch_date
	,prim_enc_rate_sim
	,prim_enc_rate_amt
	,sec_enc_rate_sim
	,sec_enc_rate_amt
	,ter_enc_rate_sim
	,ter_enc_rate_amt
	,transaction_notes
	,trans_batch_category_id
	,section_name
	,refund_to_name
	,refund_ud_field1
	,refund_ud_field2
	,refund_ud_field3
	,refund_ud_field4
	,refund_ud_field5
	,refund_ud_field6
	,refund_ud_field7
	,refund_ud_field8
	,refund_ud_field9
	,refund_ud_field10
	)
SELECT t.practice_id
	,t.trans_id
	,c.location_id
	,t.post_date
	,t.post_ind
	,t.source_type
	,t.batch_date
	,t.batch_nbr
	,t.tracking_desc_40
	,t.source_id
	,c.person_id
	,c.amt
	,t.approved_amt
	,t.tran_date
	,t.tran_code_id
	,td.paid_amt
	,t.source
	,c.rendering_id
	,t.create_timestamp
	,t.created_by
	,t.modify_timestamp
	,t.modified_by
	,t.closing_date
	,''
	,c.invoice_desc_1
	,c.invoice_desc_2
	,td.trans_status
	,td.reason_codes_display_only
	,c.service_item_lib_id
	,c.service_item_id
	,c.begin_date_of_service
	,c.quantity
	,c.place_of_service
	,0.0
	,0.0
	,0.0
	,0.0
	,0.0
	,0.0
	,0.0
	,0.0
	,0.0
	,0.0
	,0.0
	,0.0
	,0.0
	,0.0
	,0.0
	,0.0
	,c.midlevel_id
	,td.note
	,c.note
	,c.unit_price
	,cob1_amt
	,cob2_amt
	,cob3_amt
	,pat_amt
	,cpt4_code_id
	,c.icd9cm_code_id
	,c.icd9cm_code_id_2
	,c.icd9cm_code_id_3
	,c.icd9cm_code_id_4
	,icd9cm_code_desc
	,icd9cm_code_desc_2
	,icd9cm_code_desc_3
	,icd9cm_code_desc_4
	,t.override_closing_date
	,c.revenue_description
	,c.value_code
	,c.occur_code
	,td.deduct_amt
	,td.source_id
	,td.source_type
	,c.charge_id
	,c.referring_id
	,c.referring_name
	,allowed_amt
	,pe.facility_location_id
	,c.outsource_ind
	,c.outsource_date
	,td.outsource_agency_id
	,b.description
	,mrkt_plan_id
	,mrkt_source_id
	,mrkt_source_type
	,mrkt_comments
	,mrkt_details
	,b.ent_batch_nbr
	,b.ent_batch_date
	,pe.prim_enc_rate_sim
	,pe.prim_enc_rate_amt
	,pe.sec_enc_rate_sim
	,pe.sec_enc_rate_amt
	,pe.ter_enc_rate_sim
	,pe.ter_enc_rate_amt
	,t.transaction_notes
	,b.trans_batch_category_id
	,CASE 
		WHEN c.STATUS IN (
				'B'
				,'U'
				,'H'
				,'R'
				)
			THEN 'Accounts Receivable'
		WHEN c.STATUS = 'A'
			THEN 'Bad Debt'
		WHEN c.STATUS = 'I'
			THEN 'In Progress'
		ELSE 'Accounts Receivable'
		END
	,t.refund_to_name
	,ve.ud_field1
	,ve.ud_field2
	,ve.ud_field3
	,ve.ud_field4
	,ve.ud_field5
	,ve.ud_field6
	,ve.ud_field7
	,ve.ud_field8
	,ve.ud_field9
	,ve.ud_field10
FROM transactions t
LEFT OUTER JOIN batches b ON t.batch_nbr = b.batch_nbr
	AND t.batch_date = b.batch_date
	AND t.practice_id = b.practice_id
LEFT OUTER JOIN vendor_ext ve ON (
		t.external_id1 = ve.vendor_ext_id
		AND t.external_id2 = ve.pay_to_code
		)
	,trans_detail td
	,charges c
	,patient_encounter pe
WHERE td.trans_id = t.trans_id
	AND td.practice_id = t.practice_id
	AND td.charge_id = c.charge_id
	AND pe.practice_id = c.practice_id
	AND pe.enc_id = c.source_id
	AND pe.cob1_payer_id IS NULL
	AND t.post_ind = 'Y'
	AND t.type = 'C'
	AND t.closing_date >=

@start_date
	AND t.closing_date <

dateadd(dd, 1, dateadd(dd, 1, @end_date))
	AND t.source_type IN (
		'V'
		,'I'
		,'A'
		,'B'
		)
	AND td.practice_id = @practice_id
	AND c.practice_id = @practice_id;

INSERT INTO GeneratePaymentReportTempTable (
	practice_id
	,trans_id
	,location_id
	,post_date
	,post_ind
	,source_type
	,batch_date
	,batch_nbr
	,tracking_desc_40
	,source_id
	,person_id
	,charge_amt
	,approved_amt
	,tran_date
	,tran_code_id
	,tran_amt
	,source
	,rendering_provider_id
	,create_timestamp
	,created_by
	,modify_timestamp
	,modified_by
	,closing_date
	,unapplied_trans_y_n
	,invoice_desc_1
	,invoice_desc_2
	,trans_status
	,reason_codes
	,service_item_lib_id
	,service_item_id
	,begin_date_of_service
	,quantity
	,place_of_service
	,rvu1
	,rvu1_total
	,rvu2
	,rvu2_total
	,rvu3
	,rvu3_total
	,rvu4
	,rvu4_total
	,rvu5
	,rvu5_total
	,rvu6
	,rvu6_total
	,rvu7
	,rvu7_total
	,rvu8
	,rvu8_total
	,midlevel_id
	,td_notes
	,ch_notes
	,unit_price
	,cob1_amt
	,cob2_amt
	,cob3_amt
	,pat_amt
	,cpt4_code_id
	,icd9cm_code_id
	,icd9cm_code_id_2
	,icd9cm_code_id_3
	,icd9cm_code_id_4
	,icd9cm_code_desc
	,icd9cm_code_desc_2
	,icd9cm_code_desc_3
	,icd9cm_code_desc_4
	,override_closing_date
	,revenue_description
	,value_code
	,occur_code
	,deductible_amt
	,detail_id
	,detail_type
	,charge_id
	,chg_refer_id
	,chg_refer_name
	,allowed_amt
	,outsource_ind
	,outsource_date
	,outsource_agency_id
	,batch_description
	,enc_nbr
	,ent_batch_nbr
	,ent_batch_date
	,transaction_notes
	,trans_batch_category_id
	,section_name
	,refund_to_name
	,refund_ud_field1
	,refund_ud_field2
	,refund_ud_field3
	,refund_ud_field4
	,refund_ud_field5
	,refund_ud_field6
	,refund_ud_field7
	,refund_ud_field8
	,refund_ud_field9
	,refund_ud_field10
	)
SELECT t.practice_id
	,t.trans_id
	,c.location_id
	,t.post_date
	,t.post_ind
	,t.source_type
	,t.batch_date
	,t.batch_nbr
	,t.tracking_desc_40
	,t.source_id
	,t.person_id
	,c.amt
	,t.approved_amt
	,t.tran_date
	,t.tran_code_id
	,td.paid_amt
	,t.source
	,c.rendering_id
	,t.create_timestamp
	,t.created_by
	,t.modify_timestamp
	,t.modified_by
	,t.closing_date
	,''
	,c.invoice_desc_1
	,c.invoice_desc_2
	,td.trans_status
	,td.reason_codes_display_only
	,c.service_item_lib_id
	,c.service_item_id
	,c.begin_date_of_service
	,c.quantity
	,c.place_of_service
	,0.0
	,0.0
	,0.0
	,0.0
	,0.0
	,0.0
	,0.0
	,0.0
	,0.0
	,0.0
	,0.0
	,0.0
	,0.0
	,0.0
	,0.0
	,0.0
	,c.midlevel_id
	,td.note
	,c.note
	,c.unit_price
	,cob1_amt
	,cob2_amt
	,cob3_amt
	,pat_amt
	,cpt4_code_id
	,c.icd9cm_code_id
	,c.icd9cm_code_id_2
	,c.icd9cm_code_id_3
	,c.icd9cm_code_id_4
	,icd9cm_code_desc
	,icd9cm_code_desc_2
	,icd9cm_code_desc_3
	,icd9cm_code_desc_4
	,t.override_closing_date
	,c.revenue_description
	,c.value_code
	,c.occur_code
	,td.deduct_amt
	,td.source_id
	,td.source_type
	,c.charge_id
	,c.referring_id
	,c.referring_name
	,allowed_amt
	,c.outsource_ind
	,c.outsource_date
	,td.outsource_agency_id
	,b.description
	,i.invoice_nbr
	,b.ent_batch_nbr
	,b.ent_batch_date
	,t.transaction_notes
	,b.trans_batch_category_id
	,CASE 
		WHEN c.STATUS IN (
				'B'
				,'U'
				,'H'
				,'R'
				)
			THEN 'Accounts Receivable'
		WHEN c.STATUS = 'A'
			THEN 'Bad Debt'
		WHEN c.STATUS = 'I'
			THEN 'In Progress'
		ELSE 'Accounts Receivable'
		END
	,t.refund_to_name
	,ve.ud_field1
	,ve.ud_field2
	,ve.ud_field3
	,ve.ud_field4
	,ve.ud_field5
	,ve.ud_field6
	,ve.ud_field7
	,ve.ud_field8
	,ve.ud_field9
	,ve.ud_field10
FROM transactions t
LEFT OUTER JOIN batches b ON t.batch_nbr = b.batch_nbr
	AND t.batch_date = b.batch_date
	AND t.practice_id = b.practice_id
LEFT OUTER JOIN vendor_ext ve ON (
		t.external_id1 = ve.vendor_ext_id
		AND t.external_id2 = ve.pay_to_code
		)
	,trans_detail td
	,charges c
	,invoices i
WHERE td.trans_id = t.trans_id
	AND td.practice_id = t.practice_id
	AND td.charge_id = c.charge_id
	AND td.source_type IN ('I')
	AND t.post_ind = 'Y'
	AND t.type = 'C'
	AND td.practice_id = i.practice_id
	AND td.source_id = i.invoice_id
	AND t.closing_date >=

@start_date
	AND t.closing_date <

dateadd(dd, 1, dateadd(dd, 1, @end_date))
	AND t.source_type IN (
		'V'
		,'I'
		,'A'
		,'B'
		)
	AND td.practice_id = @practice_id
	AND c.practice_id = @practice_id;

INSERT INTO GeneratePaymentReportTempTable (
	practice_id
	,trans_id
	,post_date
	,post_ind
	,source_type
	,batch_date
	,batch_nbr
	,tracking_desc_40
	,source_id
	,person_id
	,charge_amt
	,approved_amt
	,tran_date
	,tran_code_id
	,tran_amt
	,source
	,create_timestamp
	,created_by
	,modify_timestamp
	,modified_by
	,closing_date
	,financial_class_desc
	,payer_name
	,unapplied_trans_y_n
	,trans_status
	,reason_codes
	,rvu1
	,rvu1_total
	,rvu2
	,rvu2_total
	,rvu3
	,rvu3_total
	,rvu4
	,rvu4_total
	,rvu5
	,rvu5_total
	,rvu6
	,rvu6_total
	,rvu7
	,rvu7_total
	,rvu8
	,rvu8_total
	,td_notes
	,override_closing_date
	,deductible_amt
	,detail_id
	,detail_type
	,charge_id
	,allowed_amt
	,batch_description
	,outsource_ind
	,ent_batch_nbr
	,ent_batch_date
	,transaction_notes
	,trans_batch_category_id
	,section_name
	,refund_to_name
	,refund_ud_field1
	,refund_ud_field2
	,refund_ud_field3
	,refund_ud_field4
	,refund_ud_field5
	,refund_ud_field6
	,refund_ud_field7
	,refund_ud_field8
	,refund_ud_field9
	,refund_ud_field10
	)
SELECT t.practice_id
	,t.trans_id
	,t.post_date
	,t.post_ind
	,t.source_type
	,t.batch_date
	,t.batch_nbr
	,t.tracking_desc_40
	,t.source_id
	,t.person_id
	,0
	,t.approved_amt
	,t.tran_date
	,t.tran_code_id
	,td.paid_amt
	,t.source
	,t.create_timestamp
	,t.created_by
	,t.modify_timestamp
	,t.modified_by
	,t.closing_date
	,'&lt;Unapplied&gt;'
	,'&lt;Unapplied&gt;'
	,'Y'
	,td.trans_status
	,td.reason_codes_display_only
	,0.0
	,0.0
	,0.0
	,0.0
	,0.0
	,0.0
	,0.0
	,0.0
	,0.0
	,0.0
	,0.0
	,0.0
	,0.0
	,0.0
	,0.0
	,0.0
	,td.note
	,t.override_closing_date
	,td.deduct_amt
	,td.source_id
	,td.source_type
	,td.charge_id
	,allowed_amt
	,b.description
	,'N'
	,b.ent_batch_nbr
	,b.ent_batch_date
	,t.transaction_notes
	,b.trans_batch_category_id
	,'Accounts Receivable'
	,t.refund_to_name
	,ve.ud_field1
	,ve.ud_field2
	,ve.ud_field3
	,ve.ud_field4
	,ve.ud_field5
	,ve.ud_field6
	,ve.ud_field7
	,ve.ud_field8
	,ve.ud_field9
	,ve.ud_field10
FROM transactions t
LEFT OUTER JOIN batches b ON t.batch_nbr = b.batch_nbr
	AND t.batch_date = b.batch_date
	AND t.practice_id = b.practice_id
LEFT OUTER JOIN vendor_ext ve ON (
		t.external_id1 = ve.vendor_ext_id
		AND t.external_id2 = ve.pay_to_code
		)
	,trans_detail td
WHERE td.trans_id = t.trans_id
	AND td.practice_id = t.practice_id
	AND td.system_charge_code IN (
		'APVCREDIT'
		,'APACREDIT'
		,'UNAPPPAY'
		,'UNAPPADJ'
		,'CREDIT'
		,'DEBIT'
		,'ETCROFFSET'
		)
	AND t.source_type IN (
		'A'
		,'B'
		,'I'
		)
	AND t.post_ind = 'Y'
	AND t.type = 'C'
	AND t.closing_date >=

@start_date
	AND t.closing_date <

dateadd(dd, 1, dateadd(dd, 1, @end_date))
	AND t.practice_id = @practice_id;

INSERT INTO GeneratePaymentReportTempTable (
	practice_id
	,trans_id
	,location_id
	,post_date
	,post_ind
	,source_type
	,batch_date
	,batch_nbr
	,tracking_desc_40
	,source_id
	,person_id
	,charge_amt
	,approved_amt
	,tran_date
	,tran_code_id
	,tran_amt
	,source
	,create_timestamp
	,created_by
	,modify_timestamp
	,modified_by
	,closing_date
	,insured_person_id
	,payer_id
	,person_payer_id
	,financial_class
	,unapplied_trans_y_n
	,trans_status
	,reason_codes
	,rvu1
	,rvu1_total
	,rvu2
	,rvu2_total
	,rvu3
	,rvu3_total
	,rvu4
	,rvu4_total
	,rvu5
	,rvu5_total
	,rvu6
	,rvu6_total
	,rvu7
	,rvu7_total
	,rvu8
	,rvu8_total
	,td_notes
	,override_closing_date
	,deductible_amt
	,detail_id
	,detail_type
	,charge_id
	,payer_subgrouping1_id
	,payer_subgrouping2_id
	,allowed_amt
	,facility_location_id
	,batch_description
	,outsource_ind
	,mrkt_plan_id
	,mrkt_source_id
	,mrkt_source_type
	,mrkt_comments
	,mrkt_details
	,ent_batch_nbr
	,ent_batch_date
	,prim_enc_rate_sim
	,prim_enc_rate_amt
	,sec_enc_rate_sim
	,sec_enc_rate_amt
	,ter_enc_rate_sim
	,ter_enc_rate_amt
	,transaction_notes
	,contracted_payer_ind
	,refund_address_line1
	,refund_address_line2
	,refund_city
	,refund_state
	,refund_zip
	,refund_country_id
	,refund_county_id
	,resubmission_reference_nbr
	,trans_batch_category_id
	,section_name
	,refund_to_name
	,refund_ud_field1
	,refund_ud_field2
	,refund_ud_field3
	,refund_ud_field4
	,refund_ud_field5
	,refund_ud_field6
	,refund_ud_field7
	,refund_ud_field8
	,refund_ud_field9
	,refund_ud_field10
	)
SELECT t.practice_id
	,t.trans_id
	,pe.location_id
	,t.post_date
	,t.post_ind
	,t.source_type
	,t.batch_date
	,t.batch_nbr
	,t.tracking_desc_40
	,t.source_id
	,t.person_id
	,0
	,t.approved_amt
	,t.tran_date
	,t.tran_code_id
	,td.paid_amt
	,t.source
	,t.create_timestamp
	,t.created_by
	,t.modify_timestamp
	,t.modified_by
	,t.closing_date
	,pe.cob1_insured_person_id
	,pe.cob1_payer_id
	,pe.cob1_person_payer_id
	,pm.financial_class
	,'Y'
	,td.trans_status
	,td.reason_codes_display_only
	,0.0
	,0.0
	,0.0
	,0.0
	,0.0
	,0.0
	,0.0
	,0.0
	,0.0
	,0.0
	,0.0
	,0.0
	,0.0
	,0.0
	,0.0
	,0.0
	,td.note
	,t.override_closing_date
	,td.deduct_amt
	,td.source_id
	,td.source_type
	,td.charge_id
	,payer_subgrouping1_id
	,payer_subgrouping2_id
	,allowed_amt
	,pe.facility_location_id
	,b.description
	,'N'
	,mrkt_plan_id
	,mrkt_source_id
	,mrkt_source_type
	,mrkt_comments
	,mrkt_details
	,b.ent_batch_nbr
	,b.ent_batch_date
	,pe.prim_enc_rate_sim
	,pe.prim_enc_rate_amt
	,pe.sec_enc_rate_sim
	,pe.sec_enc_rate_amt
	,pe.ter_enc_rate_sim
	,pe.ter_enc_rate_amt
	,t.transaction_notes
	,pm.contracted_payer_ind
	,t.refund_address_line1
	,t.refund_address_line2
	,t.refund_city
	,t.refund_state
	,t.refund_zip
	,t.refund_country_id
	,t.refund_county_id
	,t.resubmission_reference_nbr
	,b.trans_batch_category_id
	,CASE 
		WHEN pe.enc_status IN (
				'B'
				,'U'
				,'H'
				,'R'
				)
			THEN 'Accounts Receivable'
		WHEN pe.enc_status = 'A'
			THEN 'Bad Debt'
		WHEN pe.enc_status = 'I'
			THEN 'In Progress'
		ELSE 'Accounts Receivable'
		END
	,t.refund_to_name
	,ve.ud_field1
	,ve.ud_field2
	,ve.ud_field3
	,ve.ud_field4
	,ve.ud_field5
	,ve.ud_field6
	,ve.ud_field7
	,ve.ud_field8
	,ve.ud_field9
	,ve.ud_field10
FROM transactions t
LEFT OUTER JOIN batches b ON t.batch_nbr = b.batch_nbr
	AND t.batch_date = b.batch_date
	AND t.practice_id = b.practice_id
LEFT OUTER JOIN vendor_ext ve ON (
		t.external_id1 = ve.vendor_ext_id
		AND t.external_id2 = ve.pay_to_code
		)
	,trans_detail td
	,patient_encounter pe
	,payer_mstr pm
WHERE pe.practice_id = t.practice_id
	AND pe.enc_id = t.source_id
	AND td.trans_id = t.trans_id
	AND td.practice_id = t.practice_id
	AND pe.cob1_payer_id = pm.payer_id
	AND td.system_charge_code IN (
		'APVCREDIT'
		,'APACREDIT'
		,'UNAPPPAY'
		,'UNAPPADJ'
		,'CREDIT'
		,'DEBIT'
		,'ETCROFFSET'
		)
	AND t.post_ind = 'Y'
	AND t.type = 'C'
	AND t.source_type = 'V'
	AND t.closing_date >=

@start_date
	AND t.closing_date <

dateadd(dd, 1, dateadd(dd, 1, @end_date))
	AND pe.practice_id = @practice_id
	AND t.practice_id = @practice_id;

INSERT INTO GeneratePaymentReportTempTable (
	practice_id
	,trans_id
	,location_id
	,post_date
	,post_ind
	,source_type
	,batch_date
	,batch_nbr
	,tracking_desc_40
	,source_id
	,person_id
	,charge_amt
	,approved_amt
	,tran_date
	,tran_code_id
	,tran_amt
	,source
	,create_timestamp
	,created_by
	,modify_timestamp
	,modified_by
	,closing_date
	,unapplied_trans_y_n
	,trans_status
	,reason_codes
	,rvu1
	,rvu1_total
	,rvu2
	,rvu2_total
	,rvu3
	,rvu3_total
	,rvu4
	,rvu4_total
	,rvu5
	,rvu5_total
	,rvu6
	,rvu6_total
	,rvu7
	,rvu7_total
	,rvu8
	,rvu8_total
	,td_notes
	,override_closing_date
	,deductible_amt
	,detail_id
	,detail_type
	,charge_id
	,allowed_amt
	,facility_location_id
	,batch_description
	,outsource_ind
	,mrkt_plan_id
	,mrkt_source_id
	,mrkt_source_type
	,mrkt_comments
	,mrkt_details
	,ent_batch_nbr
	,ent_batch_date
	,prim_enc_rate_sim
	,prim_enc_rate_amt
	,sec_enc_rate_sim
	,sec_enc_rate_amt
	,ter_enc_rate_sim
	,ter_enc_rate_amt
	,transaction_notes
	,trans_batch_category_id
	,refund_to_name
	,refund_ud_field1
	,refund_ud_field2
	,refund_ud_field3
	,refund_ud_field4
	,refund_ud_field5
	,refund_ud_field6
	,refund_ud_field7
	,refund_ud_field8
	,refund_ud_field9
	,refund_ud_field10
	)
SELECT t.practice_id
	,t.trans_id
	,pe.location_id
	,t.post_date
	,t.post_ind
	,t.source_type
	,t.batch_date
	,t.batch_nbr
	,t.tracking_desc_40
	,t.source_id
	,t.person_id
	,0
	,t.approved_amt
	,t.tran_date
	,t.tran_code_id
	,td.paid_amt
	,t.source
	,t.create_timestamp
	,t.created_by
	,t.modify_timestamp
	,t.modified_by
	,t.closing_date
	,'Y'
	,td.trans_status
	,td.reason_codes_display_only
	,0.0
	,0.0
	,0.0
	,0.0
	,0.0
	,0.0
	,0.0
	,0.0
	,0.0
	,0.0
	,0.0
	,0.0
	,0.0
	,0.0
	,0.0
	,0.0
	,td.note
	,t.override_closing_date
	,td.deduct_amt
	,td.source_id
	,td.source_type
	,td.charge_id
	,allowed_amt
	,pe.facility_location_id
	,b.description
	,'N'
	,mrkt_plan_id
	,mrkt_source_id
	,mrkt_source_type
	,mrkt_comments
	,mrkt_details
	,b.ent_batch_nbr
	,b.ent_batch_date
	,pe.prim_enc_rate_sim
	,pe.prim_enc_rate_amt
	,pe.sec_enc_rate_sim
	,pe.sec_enc_rate_amt
	,pe.ter_enc_rate_sim
	,pe.ter_enc_rate_amt
	,t.transaction_notes
	,b.trans_batch_category_id
	,t.refund_to_name
	,ve.ud_field1
	,ve.ud_field2
	,ve.ud_field3
	,ve.ud_field4
	,ve.ud_field5
	,ve.ud_field6
	,ve.ud_field7
	,ve.ud_field8
	,ve.ud_field9
	,ve.ud_field10
FROM transactions t
LEFT OUTER JOIN batches b ON t.batch_nbr = b.batch_nbr
	AND t.batch_date = b.batch_date
	AND t.practice_id = b.practice_id
LEFT OUTER JOIN vendor_ext ve ON (
		t.external_id1 = ve.vendor_ext_id
		AND t.external_id2 = ve.pay_to_code
		)
	,trans_detail td
	,patient_encounter pe
WHERE pe.practice_id = t.practice_id
	AND pe.enc_id = t.source_id
	AND td.trans_id = t.trans_id
	AND td.practice_id = t.practice_id
	AND pe.cob1_payer_id IS NULL
	AND td.system_charge_code IN (
		'APVCREDIT'
		,'APACREDIT'
		,'UNAPPPAY'
		,'UNAPPADJ'
		,'CREDIT'
		,'DEBIT'
		,'ETCROFFSET'
		)
	AND t.post_ind = 'Y'
	AND t.type = 'C'
	AND t.source_type = 'V'
	AND t.closing_date >=

@start_date
	AND t.closing_date <

dateadd(dd, 1, dateadd(dd, 1, @end_date))
	AND pe.practice_id = @practice_id
	AND t.practice_id = @practice_id;

UPDATE GeneratePaymentReportTempTable
SET financial_class_desc = ml.mstr_list_item_desc
FROM mstr_lists ml
WHERE GeneratePaymentReportTempTable.financial_class = ml.mstr_list_item_id
	AND ml.mstr_list_type = 'fin_class';

UPDATE GeneratePaymentReportTempTable
SET refer_name = pe.refer_provider_name
	,consult1_provider_name = pe.consult1_provider_name
	,refer_provider_id = pe.refer_provider_id
	,consult1_provider_id = pe.consult1_provider_id
	,consult2_provider_id = pe.consult2_provider_id
	,consult2_provider_name = pe.consult2_provider_name
	,admit_provider_id = pe.admit_provider_id
	,admit_provider_name = pe.admit_provider_name
	,supervisor_provider_id = pe.supervisor_provider_id
	,final_bill_date = pe.final_bill_date
	,last_bill_date = pe.last_bill_date
	,patient_type_id = pe.patient_type_id
	,enc_rendering_id = pe.rendering_provider_id
	,source_nbr = pe.enc_nbr
	,enc_nbr = pe.enc_nbr
	,fqhc_enc_ind = pe.fqhc_enc_ind
	,mrkt_plan_id = pe.mrkt_plan_id
	,mrkt_source_id = pe.mrkt_source_id
	,mrkt_source_type = pe.mrkt_source_type
	,mrkt_comments = pe.mrkt_comments
	,mrkt_details = pe.mrkt_details
	,casemgt_case_id = pe.casemgt_case_id
	,enc_homeless_status_id = pe.uds_homeless_status_id
	,agency_id = pe.agency_id
	,rental_ind = pe.rental_ind
FROM patient_encounter pe
WHERE GeneratePaymentReportTempTable.practice_id = pe.practice_id
	AND GeneratePaymentReportTempTable.detail_id = pe.enc_id
	AND GeneratePaymentReportTempTable.detail_type = 'V';

UPDATE GeneratePaymentReportTempTable
SET refer_name = isnull(pm.last_name, '') + ', ' + isnull(pm.first_name, '') + ' ' + isnull(pm.middle_name, '')
FROM provider_mstr pm
WHERE GeneratePaymentReportTempTable.refer_provider_id = pm.provider_id
	AND refer_provider_id IS NOT NULL;

UPDATE GeneratePaymentReportTempTable
SET enc_rendering_name = isnull(pm.last_name, '') + ', ' + isnull(pm.first_name, '') + ' ' + isnull(pm.middle_name, '')
FROM provider_mstr pm
WHERE GeneratePaymentReportTempTable.enc_rendering_id = pm.provider_id
	AND enc_rendering_id IS NOT NULL;

UPDATE GeneratePaymentReportTempTable
SET payer_name = pp.payer_name
FROM person_payer pp
WHERE GeneratePaymentReportTempTable.person_payer_id = pp.person_payer_id;

UPDATE GeneratePaymentReportTempTable
SET practice_name = pr.practice_name
FROM practice pr
WHERE GeneratePaymentReportTempTable.practice_id = pr.practice_id;

UPDATE GeneratePaymentReportTempTable
SET financial_class_desc = 'Self Pay'
	,payer_name = 'Self Pay'
WHERE GeneratePaymentReportTempTable.payer_id IS NULL
	AND source_type = 'V';

UPDATE GeneratePaymentReportTempTable
SET NAME = isnull(per.last_name, '') + ', ' + isnull(per.first_name, '') + ' ' + isnull(per.middle_name, '')
	,source_nbr = ac.acct_nbr
	,date_of_birth = per.date_of_birth
	,patient_age = per.date_of_birth
	,address_line_1 = per.address_line_1
	,address_line_2 = per.address_line_2
	,city = per.city
	,zip = per.zip
	,country_id = per.country_id
	,sex = per.sex
	,county_id = per.county_id
	,person_nbr = per.person_nbr
	,patient_age_unformatted = DATEDIFF(YY, per.date_of_birth, getdate()) - CASE 
		WHEN ((MONTH(per.date_of_birth) * 100 + DAY(per.date_of_birth)) >(MONTH(getdate()) * 100 + DAY(getdate())))
			THEN 1
		ELSE 0
		END
	,

patient_age_dos_unformatted = DATEDIFF(YY, per.date_of_birth, begin_date_of_service) - CASE 
		WHEN ((MONTH(per.date_of_birth) * 100 + DAY(per.date_of_birth)) >(MONTH(begin_date_of_service) * 100 + DAY(begin_date_of_service)))
			THEN 1
		ELSE 0
		END
	,

Patient_age_in_months = DATEDIFF(MM, per.date_of_birth, getdate()) - CASE 
		WHEN (DAY(per.date_of_birth) >DAY(getdate()))
			THEN 1
		ELSE 0
		END
	,

patient_age_in_months_on_dos = DATEDIFF(MM, per.date_of_birth, begin_date_of_service) - CASE 
		WHEN (DAY(per.date_of_birth) >DAY(begin_date_of_service))
			THEN 1
		ELSE 0
		END
FROM

accounts ac
	,person per
WHERE GeneratePaymentReportTempTable.source_type IN (
		'A'
		,'B'
		)
	AND GeneratePaymentReportTempTable.practice_id = ac.practice_id
	AND GeneratePaymentReportTempTable.source_id = ac.acct_id
	AND ac.guar_type = 'P'
	AND ac.guar_id = per.person_id;

UPDATE GeneratePaymentReportTempTable
SET NAME = emp.NAME
	,source_nbr = ac.acct_nbr
	,city = emp.city
	,zip = emp.zip
	,county_id = emp.county_id
FROM accounts ac
	,employer_mstr emp
WHERE GeneratePaymentReportTempTable.source_type IN (
		'A'
		,'B'
		)
	AND GeneratePaymentReportTempTable.practice_id = ac.practice_id
	AND GeneratePaymentReportTempTable.source_id = ac.acct_id
	AND ac.guar_type = 'E'
	AND ac.guar_id = emp.employer_id;

UPDATE GeneratePaymentReportTempTable
SET NAME = isnull(per.last_name, '') + ', ' + isnull(per.first_name, '') + ' ' + isnull(per.middle_name, '')
	,city = per.city
	,zip = per.zip
	,source_nbr = inv.invoice_nbr
	,county_id = per.county_id
	,person_nbr = per.person_nbr
FROM invoices inv
	,accounts ac
	,person per
WHERE GeneratePaymentReportTempTable.source_type = 'I'
	AND GeneratePaymentReportTempTable.practice_id = inv.practice_id
	AND GeneratePaymentReportTempTable.source_id = inv.invoice_id
	AND inv.practice_id = ac.practice_id
	AND inv.acct_id = ac.acct_id
	AND ac.guar_type = 'P'
	AND ac.guar_id = per.person_id;

UPDATE GeneratePaymentReportTempTable
SET NAME = emp.NAME
	,city = emp.city
	,zip = emp.zip
	,source_nbr = inv.invoice_nbr
	,county_id = emp.county_id
FROM invoices inv
	,accounts ac
	,employer_mstr emp
WHERE GeneratePaymentReportTempTable.source_type = 'I'
	AND GeneratePaymentReportTempTable.practice_id = inv.practice_id
	AND GeneratePaymentReportTempTable.source_id = inv.invoice_id
	AND inv.practice_id = ac.practice_id
	AND inv.acct_id = ac.acct_id
	AND ac.guar_type = 'E'
	AND ac.guar_id = emp.employer_id;

UPDATE GeneratePaymentReportTempTable
SET attend_first_name = pm.first_name
	,attend_middle_name = pm.middle_name
	,attend_last_name = pm.last_name
	,provider_subgrp1_id = pm.provider_subgrouping1_id
	,provider_subgrp2_id = pm.provider_subgrouping2_id
FROM provider_mstr pm
WHERE GeneratePaymentReportTempTable.rendering_provider_id = pm.provider_id;

UPDATE GeneratePaymentReportTempTable
SET source_type_desc = ct.description
FROM code_tables ct
WHERE GeneratePaymentReportTempTable.source_type = ct.code
	AND ct.code_type = 'sys_source';

UPDATE GeneratePaymentReportTempTable
SET trans_status_desc = ct.description
FROM code_tables ct
WHERE GeneratePaymentReportTempTable.trans_status = ct.code
	AND ct.code_type = 'sys_td_status';

UPDATE GeneratePaymentReportTempTable
SET department = sim.department
	,component = sim.component
	,modality = sim.modality
	,revenue_code = sim.revenue_code
	,aftercare_days = sim.aftercare_days
	,service_item_description = sim.description
FROM service_item_mstr sim
WHERE GeneratePaymentReportTempTable.service_item_id = sim.service_item_id
	AND GeneratePaymentReportTempTable.service_item_lib_id = sim.service_item_lib_id
	AND begin_date_of_service BETWEEN sim.eff_date
		AND sim.exp_date;

UPDATE GeneratePaymentReportTempTable
SET GeneratePaymentReportTempTable.location_name = l.location_name
	,GeneratePaymentReportTempTable.location_subgrouping1_id = l.location_subgrouping1_id
	,GeneratePaymentReportTempTable.location_subgrouping2_id = l.location_subgrouping2_id
FROM location_mstr l
WHERE GeneratePaymentReportTempTable.location_id = l.location_id;