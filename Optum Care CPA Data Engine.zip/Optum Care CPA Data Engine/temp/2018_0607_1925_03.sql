select * from charges where begin_date_of_service = '20171116'

select * from INFORMATION_SCHEMA.COLUMNS where lower(column_name) like '%process%'
order by table_name

select top 10 * from charges

select * from accounts
left outer join appointments on accounts.site_id = appointments.site_id
left outer join invoices on accounts.site_id = invoices.site_id


select practice.practice_name,appointments.*,person.* from appointments
join practice on practice.practice_id = appointments.practice_id
join charges on charges.practice_id = appointments.practice_id
join person on person.person_id = appointments.person_id

select count(*) from person