CREATE TABLE dbo.tcl_USONTableTemp
(practice_id                    CHAR(4) NOT NULL,
practice_name                  VARCHAR(40) NULL,
location_id                    UNIQUEIDENTIFIER NULL,
source_id                      UNIQUEIDENTIFIER NOT NULL,
enc_nbr                        NUMERIC NULL,
source_type                    CHAR(1) NOT NULL,
source_type_desc               VARCHAR(200) NULL,
begin_date_of_service          CHAR(8) NULL,
person_id                      UNIQUEIDENTIFIER NULL,
name                           VARCHAR(150) NULL,
service_item_lib_id            UNIQUEIDENTIFIER NULL,
service_item_id                CHAR(12) NULL,
service_item_description       VARCHAR(80) NULL,
cpt4_code_id                   CHAR(13) NULL,
cpt4_description               VARCHAR(50) NULL,
icd9cm_code_id                 VARCHAR(10) NULL,
icd9cm_code_id_2               VARCHAR(10) NULL,
icd9cm_code_id_3               VARCHAR(10) NULL,
icd9cm_code_id_4               VARCHAR(10) NULL,
insured_person_id              UNIQUEIDENTIFIER NULL,
admit_provider_id              UNIQUEIDENTIFIER NULL,
admit_provider_name            VARCHAR(78) NULL,
consult1_provider_id           UNIQUEIDENTIFIER NULL,
consult1_provider_name         VARCHAR(78) NULL,
consult2_provider_id           UNIQUEIDENTIFIER NULL,
consult2_provider_name         VARCHAR(78) NULL,
supervisor_provider_id         UNIQUEIDENTIFIER NULL,
supervisor_provider_name       VARCHAR(78) NULL,
quantity                       DEC(19, 2) NULL,
extended_amt                   MONEY NULL,
user_defined1_amt              MONEY NULL,
user_defined2_amt              MONEY NULL,
override_amount                MONEY NULL,
place_of_service               CHAR(2) NULL,
place_of_service_desc          VARCHAR(200) NULL,
attend_phys_name               VARCHAR(78) NULL,
rendering_provider_id          UNIQUEIDENTIFIER NULL,
refer_provider_id              UNIQUEIDENTIFIER NULL,
enc_rendering_id               UNIQUEIDENTIFIER NULL,
enc_rendering_name             VARCHAR(78) NULL,
department                     UNIQUEIDENTIFIER NULL,
department_desc                VARCHAR(100) NULL,
modality                       UNIQUEIDENTIFIER NULL,
modality_desc                  VARCHAR(100) NULL,
component                      CHAR(1) NULL,
component_desc                 VARCHAR(200) NULL,
revenue_code                   CHAR(4) NULL,
rvu1                           FLOAT NULL,
rvu1_total                     FLOAT NULL,
rvu2                           FLOAT NULL,
rvu2_total                     FLOAT NULL,
rvu3                           FLOAT NULL,
rvu3_total                     FLOAT NULL,
rvu4                           FLOAT NULL,
rvu4_total                     FLOAT NULL,
rvu5                           FLOAT NULL,
rvu5_total                     FLOAT NULL,
rvu6                           FLOAT NULL,
rvu6_total                     FLOAT NULL,
rvu7                           FLOAT NULL,
rvu7_total                     FLOAT NULL,
rvu8                           FLOAT NULL,
rvu8_total                     FLOAT NULL,
aftercare_days                 INTEGER NULL,
payer_id                       UNIQUEIDENTIFIER NULL,
person_payer_id                UNIQUEIDENTIFIER NULL,
payer_name                     VARCHAR(40) NULL,
financial_class                UNIQUEIDENTIFIER NULL,
financial_class_desc           VARCHAR(100) NULL,
refer_provider_name            VARCHAR(78) NULL,
status                         CHAR(1) NULL,
status_desc                    VARCHAR(200) NULL,
create_timestamp               DATETIME NULL,
created_by                     INT NOT NULL,
modified_by                    INT NOT NULL,
created_by_desc                VARCHAR(40) NULL,
modify_timestamp               DATETIME NULL,
modified_by_desc               VARCHAR(40) NULL,
closing_date                   CHAR(8) NULL,
invoice_desc_1                 VARCHAR(120) NULL,
invoice_desc_2                 VARCHAR(120) NULL,
patient_type_id                UNIQUEIDENTIFIER NULL,
patient_type_desc              VARCHAR(100) NULL,
end_date_of_service            CHAR(8) NULL,
midlevel_id                    UNIQUEIDENTIFIER NULL,
unit_price                     MONEY NULL,
override_ind                   CHAR(1) NULL,
modifier_1                     CHAR(2) NULL,
modifier_2                     CHAR(2) NULL,
modifier_3                     CHAR(2) NULL,
modifier_4                     CHAR(2) NULL,
notes                          VARCHAR(255) NULL,
link_id                        UNIQUEIDENTIFIER NULL,
mid_last_name                  VARCHAR(25) NULL,
mid_first_name                 VARCHAR(25) NULL,
mid_middle_name                VARCHAR(25) NULL,
link_ind                       CHAR(1) NULL,
icd9cm_code_desc               VARCHAR(255) NULL,
icd9cm_code_desc_2             VARCHAR(255) NULL,
icd9cm_code_desc_3             VARCHAR(255) NULL,
address_line_1                 VARCHAR(55) NULL,
address_line_2                 VARCHAR(55) NULL,
icd9cm_code_desc_4             VARCHAR(255) NULL,
date_of_birth                  CHAR(8) NULL,
patient_age                    CHAR(8) NULL,
city                           VARCHAR(35) NULL,
state                          CHAR(3) NULL,
zip                            CHAR(9) NULL,
country_id                     UNIQUEIDENTIFIER NULL,
county_id                      UNIQUEIDENTIFIER,
county_desc                    VARCHAR(100) NULL,
sex                            CHAR(1) NULL,
sex_desc                       VARCHAR(30) NULL,
seq_nbr                        SMALLINT NULL,
batch_info                     VARCHAR(40) NULL,
override_closing_date          CHAR(8) NULL,
ssn                            VARCHAR(9) NULL,
revenue_description            VARCHAR(80) NULL,
value_code                     CHAR(2) NULL,
occur_code                     CHAR(2) NULL,
narrative                      VARCHAR(255) NULL,
provider_subgrp1_id            UNIQUEIDENTIFIER NULL,
provider_subgrp1_desc          VARCHAR(100) NULL,
provider_subgrp2_id            UNIQUEIDENTIFIER NULL,
provider_subgrp2_desc          VARCHAR(100) NULL,
patient_status_id              UNIQUEIDENTIFIER NULL,
patient_status_desc            VARCHAR(40),
patient_status_rsn_chng_id     UNIQUEIDENTIFIER NULL,
patient_status_reason_desc     VARCHAR(100) NULL,
ud_demo1_id                    UNIQUEIDENTIFIER NULL,
ud_demo1                       CHAR(100) NULL,
ud_demo2_id                    UNIQUEIDENTIFIER NULL,
ud_demo2                       CHAR(100) NULL,
ud_demo3_id                    UNIQUEIDENTIFIER NULL,
ud_demo3                       CHAR(100) NULL,
ud_demo4_id                    UNIQUEIDENTIFIER NULL,
ud_demo4                       CHAR(100) NULL,
ud_demo5_id                    UNIQUEIDENTIFIER NULL,
ud_demo5                       CHAR(100) NULL,
ud_demo6_id                    UNIQUEIDENTIFIER NULL,
ud_demo6                       CHAR(100) NULL,
ud_demo7_id                    UNIQUEIDENTIFIER NULL,
ud_demo7                       CHAR(100) NULL,
ud_demo8_id                    UNIQUEIDENTIFIER NULL,
ud_demo8                       CHAR(100) NULL,
ud_demo9_id                    UNIQUEIDENTIFIER NULL,
ud_demo9                       CHAR(100) NULL,
ud_demo10_id                   UNIQUEIDENTIFIER NULL,
ud_demo10                      CHAR(100) NULL,
ud_demo11_id                   UNIQUEIDENTIFIER NULL,
ud_demo11                      CHAR(100) NULL,
ud_demo12_id                   UNIQUEIDENTIFIER NULL,
ud_demo12                      CHAR(100) NULL,
ud_demo13_id                   UNIQUEIDENTIFIER NULL,
ud_demo13                      CHAR(100) NULL,
ud_demo14_id                   UNIQUEIDENTIFIER NULL,
ud_demo14                      CHAR(100) NULL,
quadrant                       CHAR(2) NULL,
tooth                          CHAR(2) NULL,
surface                        VARCHAR(12) NULL,
form                           CHAR(4) NULL,
quad_desc                      VARCHAR(200) NULL,
tooth_desc                     VARCHAR(200) NULL,
surface_description            VARCHAR(200) NULL,
form_desc                      VARCHAR(200) NULL,
aneth_base_unit                INT NULL,
aneth_start_time               CHAR(4) NULL,
aneth_stop_time                CHAR(4) NULL,
aneth_total_time               INT NULL,
aneth_alt_code                 CHAR(9) NULL,
charge_id                      UNIQUEIDENTIFIER NOT NULL,
source                         CHAR(1) NULL,
chg_referring_id               UNIQUEIDENTIFIER NULL,
chg_referring_name             VARCHAR(78) NULL,
location_name                  VARCHAR(40) NULL,
location_subgrouping1_id       UNIQUEIDENTIFIER NULL,
location_subgrouping2_id       UNIQUEIDENTIFIER NULL,
location_subgrouping1_desc     VARCHAR(100) NULL,
location_subgrouping2_desc     VARCHAR(100) NULL,
facility_location_id           UNIQUEIDENTIFIER NULL,
facility_name                  VARCHAR(40) NULL,
outsource_date                 CHAR(8) NULL,
outsource_ind                  CHAR(1) NULL,
outsource_agency_id            UNIQUEIDENTIFIER,
outsource_agency_desc          VARCHAR(40) NULL,
payer_subgrouping1_id          UNIQUEIDENTIFIER NULL,
payer_subgrouping2_id          UNIQUEIDENTIFIER NULL,
payer_subgrouping1_desc        VARCHAR(100) NULL,
payer_subgrouping2_desc        VARCHAR(100) NULL,
onset_date                     CHAR(8) NULL,
onset_time                     VARCHAR(4) NULL,
accident_code                  CHAR(1) NULL,
auto_accd_loc                  CHAR(2) NULL,
fqhc_enc_ind                   CHAR(1) NULL,
precert_nbr                    VARCHAR(50) NULL,
out_line_item_age              INT NULL,
person_nbr                     CHAR(12) NULL,
guar_name                      VARCHAR(150) NULL,
guar_address_line_1            VARCHAR(55) NULL,
guar_address_line_2            VARCHAR(55) NULL,
guar_city                      VARCHAR(35) NULL,
guar_state                     CHAR(3) NULL,
guar_zip                       CHAR(9) NULL,
guar_country_id                UNIQUEIDENTIFIER,
guar_home_phone                CHAR(10) NULL,
guar_day_phone                 CHAR(10) NULL,
guar_day_phone_ext             VARCHAR(10) NULL,
patient_guar_relation          VARCHAR(200) NULL,
guar_id                        UNIQUEIDENTIFIER,
guar_type                      CHAR(1) NULL,
guar_person_nbr                CHAR(12) NULL,
acct_nbr                       VARCHAR(9) NULL,
pat_prov_name_1                VARCHAR(75),
pat_prov_name_2                VARCHAR(75),
pat_prov_name_3                VARCHAR(75),
pat_prov_name_4                VARCHAR(75),
pat_prov_name_5                VARCHAR(75),
pat_prov_name_6                VARCHAR(75),
pat_prov_name_7                VARCHAR(75),
pat_prov_name_8                VARCHAR(75),
pat_prov_name_9                VARCHAR(75),
pat_prov_name_10               VARCHAR(75),
pat_prov_name_11               VARCHAR(75),
pat_prov_name_12               VARCHAR(75),
refer_address_line_1           VARCHAR(55) NULL,
refer_address_line_2           VARCHAR(55) NULL,
refer_city                     VARCHAR(35) NULL,
refer_state                    CHAR(3) NULL,
refer_zip                      CHAR(9) NULL,
refer_country_id               UNIQUEIDENTIFIER NULL,
refer_county_id                UNIQUEIDENTIFIER,
refer_county_desc              VARCHAR(100) NULL,
mrkt_plan_id                   UNIQUEIDENTIFIER NULL,
mrkt_source_id                 UNIQUEIDENTIFIER NULL,
mrkt_source_type               INTEGER NULL,
mrkt_comments                  VARCHAR(255) NULL,
mrkt_details                   VARCHAR(255),
mrkt_plan                      UNIQUEIDENTIFIER NULL,
marketing_desc                 VARCHAR(40) NULL,
marketing_plan_desc            VARCHAR(100) NULL,
med_rec_nbr                    CHAR(12) NULL,
diag1_riskadj_ind              CHAR(1) NULL,
diag2_riskadj_ind              CHAR(1) NULL,
diag3_riskadj_ind              CHAR(1) NULL,
diag4_riskadj_ind              CHAR(1) NULL,
sliding_fee_id                 UNIQUEIDENTIFIER,
sliding_fee_detail_id          UNIQUEIDENTIFIER,
sliding_fee_sched_dtl_desc     VARCHAR(80) NULL,
hist_family_size_nbr           INTEGER,
family_size_nbr                INTEGER,
hist_family_income             NUMERIC(19, 2) NULL,
family_income                  NUMERIC(19, 2) NULL,
percentage_discount            INTEGER NULL,
sliding_fee_adj_amt            NUMERIC(19, 2) NULL,
casemgt_case_id                UNIQUEIDENTIFIER,
case_num                       NUMERIC(12, 0) NULL,
case_desc                      VARCHAR(255) NULL,
case_sts                       VARCHAR(40) NULL,
case_emp_id                    UNIQUEIDENTIFIER,
case_emp_name                  VARCHAR(40) NULL,
statement_aging_date           VARCHAR(8) NULL,
enc_days                       INTEGER,
uds_homeless_status_id         UNIQUEIDENTIFIER NULL,
uds_homeless_status_desc       VARCHAR(100) NULL,
uds_migrant_worker_status_id   UNIQUEIDENTIFIER NULL,
uds_migrant_worker_status_desc VARCHAR(100) NULL,
uds_language_barrier_id        UNIQUEIDENTIFIER NULL,
uds_language_barrier_desc      VARCHAR(100) NULL,
uds_primary_med_coverage_id    UNIQUEIDENTIFIER NULL,
uds_primary_med_coverage_desc  VARCHAR(100) NULL,
race_desc                      VARCHAR(255),
ethnicity_id                   UNIQUEIDENTIFIER NULL,
ethnicity_desc                 VARCHAR(100) NULL,
uds_tribal_affiliation_id      UNIQUEIDENTIFIER NULL,
uds_tribal_affiliation_desc    VARCHAR(100) NULL,
uds_blood_quantum_id           UNIQUEIDENTIFIER NULL,
uds_blood_quantum_desc         VARCHAR(100) NULL,
uds_school_hlth_ctr_id         UNIQUEIDENTIFIER NULL,
uds_school_hlth_ctr_desc       VARCHAR(100),
uds_pub_hsng_pri_care_id       UNIQUEIDENTIFIER NULL,
uds_pub_hsng_pri_care_desc     VARCHAR(100) NULL,
uds_veteran_status             CHAR(1) NULL,
uds_veteran_status_desc        VARCHAR(100) NULL,
uds_consent_to_treat_ind       CHAR(1) NULL,
poverty_pct                    NUMERIC NULL,
poverty_cat                    VARCHAR(20) NULL,
patient_age_unformatted        INTEGER NULL,
patient_age_dos_unformatted    INTEGER NULL,
user_defined1                  VARCHAR(40) NULL,
user_defined2                  VARCHAR(40) NULL,
user_defined3                  VARCHAR(40) NULL,
user_defined4                  VARCHAR(40) NULL,
uds_descendancy_id             UNIQUEIDENTIFIER NULL,
uds_descendancy_desc           VARCHAR(100) NULL,
uds_ihs_elig_status_id         UNIQUEIDENTIFIER NULL,
uds_ihs_elig_status_desc       VARCHAR(100) NULL,
uds_tribal_class_id            UNIQUEIDENTIFIER NULL,
uds_tribal_class_desc          VARCHAR(100) NULL,
uds_consent_to_treat_date      CHAR(8) NULL,
community_code_id              UNIQUEIDENTIFIER NULL,
community_code_desc            VARCHAR(100),
enc_homeless_status_id         UNIQUEIDENTIFIER,
enc_homeless_status_desc       VARCHAR(100) NULL,
primary_dental_prov_id         UNIQUEIDENTIFIER NULL,
primary_dental_prov_name       VARCHAR(75) NULL,
prim_enc_rate_sim              VARCHAR(13) NULL,
prim_enc_rate_amt              NUMERIC(19, 2) NULL,
sec_enc_rate_sim               VARCHAR(13) NULL,
sec_enc_rate_amt               NUMERIC(19, 2) NULL,
ter_enc_rate_sim               VARCHAR(13) NULL,
ter_enc_rate_amt               NUMERIC(19, 2) NULL,
refused_to_report_ind          CHAR(1) NULL,
referral_nbr                   VARCHAR(50) NULL,
patient_age_in_months          INTEGER NULL,
patient_age_in_months_on_dos   INTEGER NULL,
icd_type                       VARCHAR(2) NULL,
icd_type_2                     VARCHAR(2) NULL,
icd_type_3                     VARCHAR(2) NULL,
icd_type_4                     VARCHAR(2) NULL,
diagnosis_subgroup1_id         VARCHAR(255) NULL,
diagnosis_subgroup1            VARCHAR(255) NULL,
diagnosis_subgroup2_id         VARCHAR(255) NULL,
diagnosis_subgroup2            VARCHAR(255) NULL,
diagnosis_subgroup1_id_2       VARCHAR(255) NULL,
diagnosis_subgroup1_2          VARCHAR(255) NULL,
diagnosis_subgroup1_id_3       VARCHAR(255) NULL,
diagnosis_subgroup1_3          VARCHAR(255) NULL,
diagnosis_subgroup1_id_4       VARCHAR(255) NULL,
diagnosis_subgroup1_4          VARCHAR(255) NULL,
diagnosis_subgroup2_id_2       VARCHAR(255) NULL,
diagnosis_subgroup2_2          VARCHAR(255) NULL,
diagnosis_subgroup2_id_3       VARCHAR(255) NULL,
diagnosis_subgroup2_3          VARCHAR(255) NULL,
diagnosis_subgroup2_id_4       VARCHAR(255) NULL,
diagnosis_subgroup2_4          VARCHAR(255) NULL,
diag_cat_id                    VARCHAR(255) NULL,
diag_cat_id_2                  VARCHAR(255) NULL,
diag_cat_id_3                  VARCHAR(255) NULL,
diag_cat_id_4                  VARCHAR(255) NULL,
diag_cat                       VARCHAR(1000) NULL,
diag_cat_2                     VARCHAR(1000) NULL,
diag_cat_3                     VARCHAR(1000) NULL,
diag_cat_4                     VARCHAR(1000) NULL,
contracted_payer_ind           CHAR(1) NULL,
rx_on_file_ind                 CHAR(1) NULL,
unassigned_benefit             NUMERIC(19, 2) NULL,
unassigned_benefit_fac         NUMERIC(19, 2) NULL,
section_name                   VARCHAR(40) NULL,
dateapp_placed                 CHAR(8) NULL,
time_based_units               NUMERIC(19, 2) NULL,
modifier_units                 NUMERIC(19, 2) NULL,
total_units                    NUMERIC(19, 2) NULL,
mda_provider_id                UNIQUEIDENTIFIER NULL,
mda_provider_name              VARCHAR(75) NULL,
enc_mda_provider_id            UNIQUEIDENTIFIER NULL,
enc_mda_provider_name          VARCHAR(75) NULL,
surgical_proc_code_id          VARCHAR(13) NULL,
surgical_proc_desc             VARCHAR(50) NULL,
national_drug_code             VARCHAR(11) NULL,
--basis_of_measure               VARCHAR(2) NULL,
--national_drug_units            VARCHAR(20) NULL,
COB1_Alt_Dx                    VARCHAR(1000) NULL,
COB2_Alt_Dx                    VARCHAR(1000) NULL,
COB3_Alt_Dx                    VARCHAR(1000) NULL
);




INSERT into dbo.tcl_USONTableTemp
(practice_id, location_id, source_id, enc_nbr, 
source_type, begin_date_of_service, person_id, 
service_item_lib_id, service_item_id, cpt4_code_id, 
icd9cm_code_id, icd9cm_code_id_2, icd9cm_code_id_3, 
icd9cm_code_id_4, icd9cm_code_desc, icd9cm_code_desc_2, 
icd9cm_code_desc_3, icd9cm_code_desc_4, quantity, 
extended_amt, user_defined1_amt, user_defined2_amt, 
place_of_service, payer_id, insured_person_id, 
person_payer_id, financial_class, rendering_provider_id, 
admit_provider_id, admit_provider_name, 
refer_provider_id, refer_provider_name, 
consult1_provider_id, consult1_provider_name, 
consult2_provider_id, consult2_provider_name, status, 
create_timestamp, created_by, modify_timestamp, 
modified_by, closing_date, invoice_desc_1, 
invoice_desc_2, patient_type_id, end_date_of_service, 
modifier_1, modifier_2, modifier_3, modifier_4, 
midlevel_id, notes, unit_price, override_ind, 
link_id, practice_name, supervisor_provider_id, 
seq_nbr, override_closing_date, batch_info,
revenue_description, value_code, occur_code, 
narrative, quadrant, tooth, surface, surface_description, 
form, charge_id, source, chg_referring_id, 
chg_referring_name, facility_location_id, outsource_date, 
outsource_ind, outsource_agency_id, payer_subgrouping1_id, 
payer_subgrouping2_id, onset_date, onset_time, accident_code, 
auto_accd_loc, fqhc_enc_ind, precert_nbr, guar_id, guar_type, 
enc_rendering_id, mrkt_plan_id, mrkt_source_id, mrkt_source_type, 
mrkt_comments, mrkt_details, casemgt_case_id, statement_aging_date, 
user_defined1, user_defined2, user_defined3, user_defined4, 
enc_homeless_status_id, prim_enc_rate_sim, prim_enc_rate_amt, 
sec_enc_rate_sim, sec_enc_rate_amt, ter_enc_rate_sim, 
ter_enc_rate_amt,referral_nbr, contracted_payer_ind, 
rx_on_file_ind,section_name, dateapp_placed, time_based_units, 
modifier_units, total_units, mda_provider_id, enc_mda_provider_id, 
surgical_proc_code_id, surgical_proc_desc, national_drug_code)--, basis_of_measure, national_drug_units) 



SELECT c.practice_id, c.location_id, c.source_id, pe.enc_nbr, c.source_type, 
c.begin_date_of_service, c.person_id, c.service_item_lib_id, c.service_item_id, 
c.cpt4_code_id, c.icd9cm_code_id, c.icd9cm_code_id_2, c.icd9cm_code_id_3, 
c.icd9cm_code_id_4, c.icd9cm_code_desc, c.icd9cm_code_desc_2, c.icd9cm_code_desc_3, 
c.icd9cm_code_desc_4, c.quantity, isnull(c.Amt,0), isnull(c.user_defined1_amt,0), 
isnull(c.user_defined2_amt,0), c.place_of_service, pe.cob1_payer_id, pe.cob1_insured_person_id, 
pe.cob1_person_payer_id, p.financial_class, c.rendering_id, admit_provider_id, 
admit_provider_name, pe.refer_provider_id, pe.refer_provider_name, pe.consult1_provider_id, 
pe.consult1_provider_name, consult2_provider_id, consult2_provider_name, c.status, 
c.create_timestamp, c.created_by, c.modify_timestamp, c.modified_by, c.closing_date, 
c.invoice_desc_1, c.invoice_desc_2, pe.patient_type_id, c.end_date_of_service, 
c.modifier_1, c.modifier_2, c.modifier_3, c.modifier_4, c.midlevel_id, c.note, 
c.unit_price, c.override_ind, c.link_id, pm.practice_name, supervisor_provider_id, 
c.seq_nbr, c.override_closing_date, c.batch_info, c.revenue_description, c.value_code, 
c.occur_code, c.narrative, quadrant, tooth, surface, surface_description, 
form, c.charge_id, 'T', c.referring_id, c.referring_name,pe.facility_location_id, 
outsource_date, outsource_ind, outsource_agency_id, p.payer_subgrouping1_id, 
p.payer_subgrouping2_id, onset_date, onset_time, accident_code, auto_accd_loc, 
pe.fqhc_enc_ind, ep.precert_nbr, pe.guar_id, pe.guar_type, pe.rendering_provider_id, 
mrkt_plan_id, mrkt_source_id, mrkt_source_type, mrkt_comments, mrkt_details, 
pe.casemgt_case_id, c.statement_aging_date, pe.user_defined1, pe.user_defined2, 
pe.user_defined3, pe.user_defined4, pe.uds_homeless_status_id, pe.prim_enc_rate_sim, 
pe.prim_enc_rate_amt, pe.sec_enc_rate_sim, pe.sec_enc_rate_amt, pe.ter_enc_rate_sim, 
pe.ter_enc_rate_amt,ep.referral_nbr, contracted_payer_ind, rx_on_file_ind , 
CASE 
WHEN c.status in ('B','U','H','R') THEN 'Accounts Receivable' 
WHEN c.status = 'A' THEN 'Bad Debt' 
WHEN c.status = 'I' THEN 'In Progress'  ELSE 'Accounts Receivable' END, 
ep.Appl_placed_date,c.time_based_units, c.modifier_units,c.anesthesia_units,
c.medical_director_id, pe.medical_director_id, c.surgical_proc_code_id,
c.surgical_proc_desc, c.national_drug_code--, c.basis_of_measure, c.national_drug_units  

FROM charges c 
left outer join sliding_fee_adjustment_log sfa 
on c.charge_id = sfa.charge_id and sfa.sliding_fee_action = 'O', patient_encounter pe, payer_mstr p, practice pm, encounter_payer ep 
WHERE 
c.practice_id = pm.practice_id 
AND pe.cob1_payer_id = p.payer_id 
AND pe.practice_id = c.practice_id 
AND pe.enc_id = c.source_id 
AND c.source_type = 'V' 
AND pe.practice_id = ep.practice_id 
AND pe.enc_id = ep.enc_id 
AND pe.cob1_person_payer_id = ep.person_payer_id  
and c.closing_date >= '2018-05-01' 
and c.closing_date < dateadd(dd,1,'2018-05-02')   
and c.source_type in ('V','I')  and (c.link_id  is null)   
AND c.practice_id = '0001'



--------------------
--------------------

INSERT INTO dbo.tcl_USONTableTemp
(practice_id, location_id, source_id, enc_nbr,
source_type, begin_date_of_service, person_id, 
 service_item_lib_id, service_item_id, cpt4_code_id, 
 icd9cm_code_id, icd9cm_code_id_2, icd9cm_code_id_3, 
 icd9cm_code_id_4, icd9cm_code_desc, icd9cm_code_desc_2, 
 icd9cm_code_desc_3, icd9cm_code_desc_4, quantity, 
 extended_amt,user_defined1_amt, user_defined2_amt, 
 place_of_service, rendering_provider_id, admit_provider_id, 
 admit_provider_name, refer_provider_id, refer_provider_name, 
 consult1_provider_id, consult1_provider_name, 
 consult2_provider_id, consult2_provider_name, status, 
 create_timestamp, created_by, modify_timestamp, modified_by, 
 closing_date, invoice_desc_1, invoice_desc_2, patient_type_id, 
 end_date_of_service, modifier_1, modifier_2, modifier_3, 
 modifier_4, midlevel_id, notes, unit_price, override_ind, link_id, 
 practice_name, supervisor_provider_id, seq_nbr, override_closing_date, 
 batch_info,revenue_description, value_code, occur_code, 
 narrative, quadrant, tooth, surface, surface_description, form, 
 charge_id, source, chg_referring_id, chg_referring_name,
facility_location_id, outsource_date, outsource_ind, 
 outsource_agency_id, onset_date, onset_time, accident_code, 
 auto_accd_loc, fqhc_enc_ind, guar_id, guar_type, enc_rendering_id,
  mrkt_plan_id, mrkt_source_id, mrkt_source_type, mrkt_comments, 
  mrkt_details, casemgt_case_id, statement_aging_date, user_defined1, 
  user_defined2, user_defined3, user_defined4, enc_homeless_status_id, 
  prim_enc_rate_sim, prim_enc_rate_amt, sec_enc_rate_sim, 
  sec_enc_rate_amt, ter_enc_rate_sim, ter_enc_rate_amt, rx_on_file_ind,
  section_name, time_based_units, modifier_units, total_units, 
  mda_provider_id, enc_mda_provider_id, surgical_proc_code_id, 
  surgical_proc_desc, national_drug_code)--, basis_of_measure, national_drug_units) 
  
SELECT 
c.practice_id, c.location_id, c.source_id, pe.enc_nbr, 
c.source_type, c.begin_date_of_service, c.person_id, 
c.service_item_lib_id, c.service_item_id, c.cpt4_code_id, 
c.icd9cm_code_id, c.icd9cm_code_id_2, c.icd9cm_code_id_3, 
c.icd9cm_code_id_4, c.icd9cm_code_desc, c.icd9cm_code_desc_2, 
c.icd9cm_code_desc_3, c.icd9cm_code_desc_4, c.quantity, 
isnull(c.Amt,0), isnull(c.user_defined1_amt,0), 
isnull(c.user_defined2_amt,0), c.place_of_service, 
c.rendering_id, admit_provider_id, admit_provider_name, 
pe.refer_provider_id, pe.refer_provider_name, pe.consult1_provider_id, 
pe.consult1_provider_name, pe.consult2_provider_id, 
pe.consult2_provider_name, c.status, c.create_timestamp, 
c.created_by, c.modify_timestamp, c.modified_by, c.closing_date, 
c.invoice_desc_1, c.invoice_desc_2, pe.patient_type_id, 
c.end_date_of_service, c.modifier_1, c.modifier_2, c.modifier_3, 
c.modifier_4, c.midlevel_id, c.note, c.unit_price, c.override_ind, 
c.link_id, pm.practice_name, supervisor_provider_id, c.seq_nbr, 
c.override_closing_date, c.batch_info, c.revenue_description, 
c.value_code, c.occur_code, c.narrative, quadrant, tooth, surface, 
surface_description, form, c.charge_id, 'P', c.referring_id, 
c.referring_name ,pe.facility_location_id, outsource_date, 
outsource_ind, outsource_agency_id, onset_date, onset_time, 
accident_code, auto_accd_loc, fqhc_enc_ind, pe.guar_id, 
pe.guar_type, pe.rendering_provider_id, mrkt_plan_id, 
mrkt_source_id, mrkt_source_type, mrkt_comments, mrkt_details, 
pe.casemgt_case_id, c.statement_aging_date, pe.user_defined1, 
pe.user_defined2, pe.user_defined3, pe.user_defined4, 
pe.uds_homeless_status_id, pe.prim_enc_rate_sim, pe.prim_enc_rate_amt, 
pe.sec_enc_rate_sim, pe.sec_enc_rate_amt, pe.ter_enc_rate_sim, 
pe.ter_enc_rate_amt,rx_on_file_ind, 
CASE 
WHEN c.status in ('B','U','H','R') THEN 'Accounts Receivable' 
WHEN c.status = 'A' THEN 'Bad Debt' 
WHEN c.status = 'I' THEN 'In Progress'  ELSE 'Accounts Receivable' END,
c.time_based_units, c.modifier_units,c.anesthesia_units,
c.medical_director_id, pe.medical_director_id, c.surgical_proc_code_id,
c.surgical_proc_desc, c.national_drug_code--, c.basis_of_measure, c.national_drug_units 

FROM 
charges c left outer join sliding_fee_adjustment_log sfa on c.charge_id = sfa.charge_id 
and sfa.sliding_fee_action = 'O', patient_encounter pe, practice pm WHERE c.practice_id = pm.practice_id 
AND pe.cob1_payer_id is null 
AND pe.practice_id = c.practice_id 
AND pe.enc_id = c.source_id 
AND c.source_type = 'V'  
and c.closing_date >= '2018-05-01' 
and c.closing_date < dateadd(dd,1,'2018-05-02')
and c.source_type in ('V','I')  and (c.link_id  is null) 
AND c.practice_id = '0001'


------------------------------------------------------
--------------------------------------------------------
--------------------------------------------------------

INSERT INTO dbo.tcl_USONTableTemp
(practice_id, location_id, source_id, source_type, 
begin_date_of_service, person_id, service_item_lib_id, 
service_item_id, cpt4_code_id, icd9cm_code_id, icd9cm_code_id_2, 
icd9cm_code_id_3, icd9cm_code_id_4, icd9cm_code_desc, 
icd9cm_code_desc_2, icd9cm_code_desc_3, icd9cm_code_desc_4, 
quantity, extended_amt, user_defined1_amt, user_defined2_amt, 
place_of_service, rendering_provider_id, status, create_timestamp, 
created_by, modify_timestamp, modified_by, closing_date, 
invoice_desc_1, invoice_desc_2, end_date_of_service, 
modifier_1, modifier_2, modifier_3, modifier_4, midlevel_id, 
notes, unit_price, override_ind, link_id, practice_name, 
seq_nbr, override_closing_date, batch_info, revenue_description, 
value_code, occur_code, narrative, quadrant, tooth, surface, 
surface_description, form, charge_id, source, chg_referring_id, 
chg_referring_name, outsource_date, outsource_ind, 
outsource_agency_id,rx_on_file_ind, section_name, 
national_drug_code)--, basis_of_measure, national_drug_units) 

SELECT c.practice_id, c.location_id, c.source_id, c.source_type, 
c.begin_date_of_service, c.person_id, c.service_item_lib_id, 
c.service_item_id, c.cpt4_code_id, c.icd9cm_code_id, c.icd9cm_code_id_2, 
c.icd9cm_code_id_3, c.icd9cm_code_id_4, icd9cm_code_desc, 
icd9cm_code_desc_2, icd9cm_code_desc_3, icd9cm_code_desc_4, 
c.quantity, isnull(c.Amt,0), isnull(c.user_defined1_amt,0), 
isnull(c.user_defined2_amt,0), c.place_of_service, c.rendering_id, 
c.status, c.create_timestamp, c.created_by, c.modify_timestamp, 
c.modified_by, c.closing_date, c.invoice_desc_1, c.invoice_desc_2, 
c.end_date_of_service, c.modifier_1, c.modifier_2, c.modifier_3, 
c.modifier_4, c.midlevel_id, c.note, c.unit_price, c.override_ind, 
c.link_id, pm.practice_name, c.seq_nbr, c.override_closing_date, 
c.batch_info, c.revenue_description, c.value_code, c.occur_code, 
c.narrative, quadrant, tooth, surface, surface_description, form, 
c.charge_id, '', c.referring_id, c.referring_name, outsource_date, 
outsource_ind, outsource_agency_id,rx_on_file_ind , 
CASE 
WHEN c.status in ('B','U','H','R') THEN 'Accounts Receivable' 
WHEN c.status = 'A' THEN 'Bad Debt' 
WHEN c.status = 'I' THEN 'In Progress' 
ELSE 'Accounts Receivable' 
END, c.national_drug_code--, c.basis_of_measure, c.national_drug_units  

FROM charges c, practice pm 

WHERE 
c.practice_id = pm.practice_id 
AND c.source_type = 'I'  
and c.closing_date >= '2018-05-01'
and c.closing_date < dateadd(dd,1,'2018-05-02')   
and c.source_type in ('V','I')  and (c.link_id  is null)   
AND c.practice_id = '0001'


------------------------------------------------------
--------------------------------------------------------
--------------------------------------------------------
------------------------------------------------------
--------------------------------------------------------
--------------------------------------------------------


UPDATE dbo.tcl_USONTableTemp 
SET link_ind = 'Y' WHERE link_id is not null

UPDATE dbo.tcl_USONTableTemp 
SET name = isnull(per.last_name,'')  +  ', '  +  isnull(per.first_name,'')  +  ' '  +  isnull(per.middle_name,''), 
date_of_birth = per.date_of_birth, patient_age = per.date_of_birth, address_line_1 = per.address_line_1, address_line_2 = per.address_line_2, 
city = per.city, state= per.state, zip = per.zip, country_id = per.country_id, sex = per.sex, county_id = per.county_id, person_nbr = per.person_nbr, 
ssn = per.ssn, med_rec_nbr = pat.med_rec_nbr, uds_homeless_status_id = per.uds_homeless_status_id, uds_migrant_worker_status_id = per.uds_migrant_worker_status_id,  
uds_language_barrier_id = per.uds_language_barrier_id, uds_primary_med_coverage_id = per.uds_primary_med_coverage_id,  ethnicity_id = per.ethnicity_id, 
uds_tribal_affiliation_id = per.uds_tribal_affiliation_id, uds_blood_quantum_id = per.uds_blood_quantum_id, uds_school_hlth_ctr_id = per.uds_school_hlth_ctr_id, 
uds_pub_hsng_pri_care_id = per.uds_pub_hsng_pri_care_id, uds_veteran_status = per.uds_veteran_status, uds_consent_to_treat_ind = per.uds_consent_to_treat_ind, 
patient_age_unformatted = DATEDIFF(YY, per.date_of_birth, getdate()) - CASE WHEN( (MONTH(per.date_of_birth)*100 + DAY(per.date_of_birth)) > (MONTH(getdate())*100 + DAY(getdate())) ) THEN 1 ELSE 0 END, 
patient_age_dos_unformatted = DATEDIFF(YY, per.date_of_birth, begin_date_of_service) - CASE WHEN( (MONTH(per.date_of_birth)*100 + DAY(per.date_of_birth)) > (MONTH(begin_date_of_service)*100 + DAY(begin_date_of_service)) ) THEN 1 ELSE 0 END, 
uds_descendancy_id = per.uds_decendancy_id, uds_ihs_elig_status_id = per.uds_ihs_elig_status_id, 
uds_tribal_class_id = per.uds_tribal_class_id, uds_consent_to_treat_date = per.uds_consent_to_treat_date, 
community_code_id = per.community_code_id, primary_dental_prov_id = per.primary_dental_prov_id,  
Patient_age_in_months  =DATEDIFF(MM, per.date_of_birth, getdate()) - CASE WHEN (DAY(per.date_of_birth) > DAY(getdate())) THEN 1 ElSE 0 END , 
patient_age_in_months_on_dos=DATEDIFF(MM, per.date_of_birth, begin_date_of_service) - CASE WHEN (DAY(per.date_of_birth) > DAY(begin_date_of_service)) THEN 1 ElSE 0 END  

FROM person per, patient pat 
WHERE dbo.tcl_USONTableTemp.person_id = per.person_id and dbo.tcl_USONTableTemp.practice_id = pat.practice_id and per.person_id = pat.person_id

UPDATE dbo.tcl_USONTableTemp 
SET cpt4_description = (select cp.description FROM cpt4_code_mstr cp 
WHERE dbo.tcl_USONTableTemp.cpt4_code_id = cp.cpt4_code_id)

UPDATE dbo.tcl_USONTableTemp 
SET name = emp.name, city = emp.city, zip = emp.zip, person_id = ac.acct_id, enc_nbr = inv.invoice_nbr, guar_id = ac.guar_id, guar_type = ac.guar_type, acct_nbr = ac.acct_nbr 
FROM invoices inv, accounts ac, employer_mstr emp 
WHERE dbo.tcl_USONTableTemp.source_type = 'I' and dbo.tcl_USONTableTemp.practice_id = inv.practice_id and dbo.tcl_USONTableTemp.source_id = inv.invoice_id and inv.practice_id = ac.practice_id and inv.acct_id = ac.acct_id and ac.guar_type = 'E' and ac.guar_id = emp.employer_id

UPDATE dbo.tcl_USONTableTemp 
SET payer_name = pp.payer_name 
FROM person_payer pp 
WHERE dbo.tcl_USONTableTemp.person_payer_id = pp.person_payer_id

UPDATE dbo.tcl_USONTableTemp 
SET financial_class_desc = (select ml.mstr_list_item_desc 
FROM mstr_lists ml 
WHERE dbo.tcl_USONTableTemp.financial_class = ml.mstr_list_item_id and ml.mstr_list_type = 'fin_class')

UPDATE dbo.tcl_USONTableTemp 
SET payer_name = 'Self Pay', financial_class_desc = 'Self Pay' 
WHERE dbo.tcl_USONTableTemp.payer_id is null

UPDATE dbo.tcl_USONTableTemp 
SET attend_phys_name = isnull(pm.last_name,'')  +  ', '  +  isnull(pm.first_name,'')  +  ' '  +  isnull(pm.middle_name,''), provider_subgrp1_id = pm.provider_subgrouping1_id, provider_subgrp2_id = pm.provider_subgrouping2_id 
From provider_mstr pm 
WHERE dbo.tcl_USONTableTemp.rendering_provider_id = pm.provider_id

UPDATE dbo.tcl_USONTableTemp 
SET refer_provider_name = isnull(pm.last_name,'')  +  ', '  +  isnull(pm.first_name,'')  +  ' '  +  isnull(pm.middle_name,''), refer_address_line_1 = pm.address_line_1, refer_address_line_2 = pm.address_line_2, refer_city = pm.city, refer_state = pm.state, refer_zip = pm.zip, refer_county_id = pm.county_id, refer_country_id = pm.country_id 
From provider_mstr pm 
WHERE dbo.tcl_USONTableTemp.refer_provider_id = pm.provider_id and refer_provider_id is not null

UPDATE dbo.tcl_USONTableTemp 
SET department = sim.department, component = sim.component, modality = sim.modality, revenue_code = sim.revenue_code, aftercare_days = sim.aftercare_days, service_item_description = sim.description,  unassigned_benefit = isnull(sim.unassigned_benefit,0), unassigned_benefit_fac = isnull(sim.unassigned_benefit_fac,0) 
From service_item_mstr sim 
WHERE dbo.tcl_USONTableTemp.service_item_id = sim.service_item_id and dbo.tcl_USONTableTemp.service_item_lib_id = sim.service_item_lib_id

UPDATE dbo.tcl_USONTableTemp 
SET patient_status_id = ps.patient_status_id, patient_status_rsn_chng_id = ps.patient_status_rsn_chng_id 
FROM patient_status ps 
WHERE dbo.tcl_USONTableTemp.practice_id = ps.practice_id AND dbo.tcl_USONTableTemp.person_id = ps.person_id

UPDATE dbo.tcl_USONTableTemp 
SET patient_status_desc = psm.description FROM patient_status_mstr psm 
WHERE dbo.tcl_USONTableTemp.practice_id = psm.practice_id AND dbo.tcl_USONTableTemp.patient_status_id = psm.patient_status_id

UPDATE dbo.tcl_USONTableTemp 
SET patient_status_reason_desc = ml.mstr_list_item_desc 
FROM mstr_lists ml 
WHERE dbo.tcl_USONTableTemp.patient_status_rsn_chng_id = ml.mstr_list_item_id AND mstr_list_type = 'pat_status_chng_reason'

UPDATE dbo.tcl_USONTableTemp 
SET dbo.tcl_USONTableTemp.location_name = l.location_name, dbo.tcl_USONTableTemp.location_subgrouping1_id = l.location_subgrouping1_id, dbo.tcl_USONTableTemp.location_subgrouping2_id = l.location_subgrouping2_id 
FROM location_mstr l 
WHERE dbo.tcl_USONTableTemp.location_id = l.location_id

UPDATE dbo.tcl_USONTableTemp 
SET facility_name = l.location_name 
FROM location_mstr l 
WHERE dbo.tcl_USONTableTemp.facility_location_id = l.location_id

UPDATE dbo.tcl_USONTableTemp 
SET rvu1 = isnull(sim.rvu1,0), rvu1_total = isnull(sim.rvu1,0) * quantity, rvu2 = isnull(sim.rvu2,0), rvu2_total = isnull(sim.rvu2,0) * quantity, rvu3 = isnull(sim.rvu3,0), rvu3_total = isnull(sim.rvu3,0) * quantity, rvu4 = isnull(sim.rvu4,0), rvu4_total = isnull(sim.rvu4,0) * quantity, rvu5 = isnull(sim.rvu5,0), rvu5_total = isnull(sim.rvu5,0) * quantity, rvu6 = isnull(sim.rvu6,0), rvu6_total = isnull(sim.rvu6,0) * quantity, rvu7 = isnull(sim.rvu7,0), rvu7_total = isnull(sim.rvu7,0) * quantity, rvu8 = isnull(sim.rvu8,0), rvu8_total = isnull(sim.rvu8,0) * quantity 
From service_item_mstr sim 
WHERE dbo.tcl_USONTableTemp.service_item_id = sim.service_item_id and dbo.tcl_USONTableTemp.service_item_lib_id = sim.service_item_lib_id and dbo.tcl_USONTableTemp.begin_date_of_service >= sim.eff_date and dbo.tcl_USONTableTemp.begin_date_of_service <= sim.exp_date



select  
location_name, attend_phys_name, refer_provider_name, 
f.name, payer_name, financial_class_desc, enc_nbr, 
f.closing_date, begin_date_of_service, 
extended_amt as charge_amt, quantity, icd9cm_code_id, 
icd9cm_code_desc, service_item_id, service_item_description, 
cpt4_code_id, cpt4_description, rvu1, facility_name, 
national_drug_code, source_type, f.practice_id, person_id, 
source_id, location_id, practice_name 
from dbo.tcl_USONTableTemp f  
order by enc_nbr, service_item_id


