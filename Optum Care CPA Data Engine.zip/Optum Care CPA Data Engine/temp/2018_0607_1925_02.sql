select * from charges
left outer join person on charges.person_id = person.person_id


select * from person where lower(last_name) = 'gondal'


select * from INFORMATION_SCHEMA.columns where lower(column_name) like '%service_item_de%'

select * from information_schema.columns 
where lower(column_name) like '%service_item_%'
and replace(table_name,'_','!') not like '%!%'
order by table_name

select * from INFORMATION_SCHEMA.columns order by table_name
 where lower(table_name) = 'transactions'

select distinct table_name from INFORMATION_SCHEMA.columns order by table_name

select * from payer_mstr

select charges.practice_id,batch_date,tran_date,type,tran_amt,billed_amt,approved_amt,source,post_ind,post_date,charges.closing_date,tracking_desc_40, 
service_item_id,cob1_amt,cob2_amt,cob3_amt,pat_amt,amt,unit_price,override_ind, charges.begin_date_of_service,end_date_of_service,charges.status, credit_date,charges.national_drug_code,
phys_org_name,phys_city,phys_state,phys_zip,patient_last_name,patient_first_name,patient_mi,patient_birthdate,patient_sex,patient_address_line_1,patient_address_line_2,patient_city,patient_state,
patient_zip,patient_phone,patient_marital_status,patient_death_ind,claim_type,ins_type, refer_provider_last,refer_provider_first,refer_provider_mi,refer_provider_state,
facility_lab_name,local_use_31,claim_payer_name,phys_last_name,phys_first_name,phys_mi from transactions
join charges 
	on transactions.person_id = charges.person_id 
	and transactions.practice_id = charges.practice_id
	and transactions.source_id = charges.source_id
join claims
	on transactions.practice_id = claims.practice_id
	and transactions.person_id = claims.person_id
join claim_detail
	on claims.claim_id = claim_detail.claim_id
where claim_payer_name = 'Cigna'
and tran_date = '2018-03-02 00:00:00.000'
and charges.closing_date = '20180302'
order by billed_amt


select * from practice





select * from claims



select * from claim_detail

select * from claims 
join transactions on claims.payer_id = transactions.payer_id 
where claim_payer_name = 'Cigna'


