use NGProd
select 
isnull(med_rec_nbr,'') as Patient_MRN
, isnull(person.last_name,'') as Patient_last_name
, isnull(person.first_name,'') as Patient_first_name
, convert(char(10), date_of_birth, 126) as Patient_date_of_birth
, isnull(person.ssn,'') as Patient_ssn
, patient.practice_id as Organization_id
, patient_encounter.enc_id as External_visit_number
, convert(char(19), patient_encounter.enc_timestamp, 120) as Encounter_date_time
, patient_encounter.rendering_provider_id as Provider_id
, provider_mstr.description as Provider_name
, case when patient_allergy.allergy_type_id ='1' then patient_allergy.allergy_id else '' end as Medication_allergy_code
, case when patient_allergy.allergy_type_id <>'1'   then patient_allergy.allergy_id else '' end as Non_medication_allergy_code
, isnull(allergy_comment,'') as Allergy_comment
, uniq_id as Accession_id
, isnull(rxn_desc,'') as Reaction_1
from person 
join patient on person.person_id = patient.person_id 
join patient_status on person.person_id = patient_status.person_id
join patient_encounter on patient_encounter.practice_id=patient.practice_id 
      and patient_encounter.person_id = patient.person_id
join patient_allergy on patient_allergy.person_id = patient_encounter.person_id 
      and patient_allergy.enc_id = patient_encounter.enc_id 
left join allergy_mstr on patient_allergy.allergy_id = allergy_mstr.allergy_id  
      and patient_allergy.allergy_type_id = allergy_mstr.allergy_type_id 
      and delete_ind <> 'Y'
left join provider_mstr on patient_encounter.rendering_provider_id = provider_mstr.provider_id     

order by person.person_id, Organization_id, External_visit_number


select * from INFORMATION_SCHEMA.COLUMNS where lower(table_name) like '%document%'