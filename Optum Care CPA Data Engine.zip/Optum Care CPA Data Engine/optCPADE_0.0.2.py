# Title: Optum Care CPA Data Engine
# Date: 7 June 2018
# Contributors: Charles Bezak; Tiffanee C. Lang (http://github.com/slicedpy)
# Purpose: Optum Care is in need of a database engine that can simply extract
# transform and load data rows from the OPTSQL01 SQL Server and MHCSMASQL01
# SQL server. These warehouse maintain the charges, payments and adjustments (CPA)
# data necessary to enable and or perform reporting, forecasting and machine learning.

# Import needed packages()
# time : this library could enable one instance of a listener versus re-occur scheduling
# on the server. While this may make it client-centric, it could allow for stop measure
# from users within the network. (For example, in the event that the data job needs to pause/idle,
# a request can be made to turn the timer off versuses turning the job off. Downside is it
# would require a self-reporting function that would allow for auditing and monitoring.

# pyodbc : this library is to enable a secure connection to the respective Microsoft SQL Server
# data instance in a standardize or encapsulated fashion.

# csv : For this proof of concept, the best approach will be to land the results into a csv that
# and excel sheet, powershell or supporting interfaces (ie web servers for mobile,
# web framworks for televised stats, etc) can reference. This will also make the data a little
# more portable. The downside to that is total lack of security. The immedaite work around for
# internal compliance is dropping the results in a secure network share or encrypted zip file.

# os: While this is a majority Windows environment, there could be a possible migration to a
# Unix/Linux based system. With this in mind, the only concern will be the latest of Python
# and not code updates. Something else to keep in mind--making this engine native on iOS devices,
# Andriod or similar.

# numpy : This will come in handy for data validation, data formatting, long precision and all
# else numbers.


# xlutils looks like we may be stepping down a couple versions...well not so fast, let's look
# into openpyxl--they got back into this race.


# Dependencies
# Permissions : the user that will run this script (either client side or server side) MUST
# have proper access to the database, network share and eventually cloud services for the
# APIs that will be put to use. This might even include a universal analytics mailbox for
# sending out notification, error logging and weekly data validation.


# Global Variables()

# Classes()

# Functions()


# Script Source: optCPADE_0.0.1.py
# File name: script_documentation.txt
# Made by: docEngine (another SlicedPy Speciality Script)


import datetime
import pyodbc
import csv
import os
import numpy
import xlutils
import smtplib


import win32com.client as win32


def SendtoSierraOutlook(FileToSend):
    outlook = win32.Dispatch('outlook.application')
    mail = outlook.createItem(0)
    mail.To = 'tiffanee.lang@optum.com'
    mail.Subject = '[REPORT DOWNLOAD]'
    #mail.Body ='Message body test foo'
    #mail.HTMLBody = '<h2>HTML Message body</h2>'

    attachment = r"C:\Users\tlang\Desktop\Optum Care CPA Data Engine\Optum Care CPA Data Engine\\"+FileToSend
    mail.Attachments.Add(attachment)
    mail.Send()
    

def GetReportCSV(InputSql,start_date='2018-01-01',end_date='2018-01-05',practice_id='0002'):
    
    cnxn = pyodbc.connect('DRIVER={ODBC Driver 13 for SQL Server};SERVER=OPTSQL01;DATABASE=NGProd;Trusted_Connection=yes;')
    cursor = cnxn.cursor()

    outputName = InputSql+start_date+"_"+end_date+"_"+practice_id+".csv"

    dir_path = os.path.dirname(os.path.realpath(__file__))

    cursor.execute('EXEC dbo.'+InputSql+' @start_date=\''+start_date+'\',@end_date=\''+end_date+'\',@practice_id=\''+practice_id+'\';')

    GetData = cursor.execute('SELECT * FROM '+InputSql+'TempTable;').fetchall()
    GetHeader = cursor.execute('SELECT column_name FROM INFORMATION_Schema.columns where table_name=\''+InputSql+'TempTable\' ORDER BY ORDINAL_POSITION ;').fetchall()

    GetData
   
    header = []
   
    for each in GetHeader:
        header.append(str(each[0]))

    with open(outputName,'w',newline='') as outcsv:
        writer = csv.writer(outcsv,delimiter=',',quotechar="'")
        writer.writerow(header)
       
        for each in GetData:
            writer = csv.writer(outcsv,delimiter=',',quotechar="\"")
            writer.writerow(list(each))

    SendtoSierraOutlook(outputName)
            
    

print(datetime.datetime.now())           

for i in ['GenerateAdjustmentReport','GeneratePaymentReport','GenerateChargeReport']:
    GetReportCSV(i)
    
print(datetime.datetime.now())    
       
       

