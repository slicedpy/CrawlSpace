# Title: NaNSense
# Date: 14 June 2018
# Contributors: Charles Bezak; Tiffanee C. Lang (http://github.com/slicedpy)
# Purpose: Optum Care is in need of a database engine that can simply extract
# transform and load data rows from the OPTSQL01 SQL Server and MHCSMASQL01
# SQL server. These warehouse maintain the charges, payments and adjustments (CPA)
# data necessary to enable and or perform reporting, forecasting and machine learning.
#
# There are columns that go completely unused and need to be eliminated from the query
# all together. This script, NaNSense, will query which columns from a sample and
# the whole dataset are NULL in all instances.

# Import needed packages()
# datetime : this library could enable one instance of a listener versus re-occur scheduling
# on the server. While this may make it client-centric, it could allow for stop measure
# from users within the network. (For example, in the event that the data job needs to pause/idle,
# a request can be made to turn the timer off versuses turning the job off. Downside is it
# would require a self-reporting function that would allow for auditing and monitoring.

# pyodbc : this library is to enable a secure connection to the respective Microsoft SQL Server
# data instance in a standardize or encapsulated fashion.


# os: While this is a majority Windows environment, there could be a possible migration to a
# Unix/Linux based system. With this in mind, the only concern will be the latest of Python
# and not code updates. Something else to keep in mind--making this engine native on iOS devices,
# Andriod or similar.


# Dependencies
# Permissions : the user that will run this script (either client side or server side) MUST
# have proper access to the database, network share and eventually cloud services for the
# APIs that will be put to use. This might even include a universal analytics mailbox for
# sending out notification, error logging and weekly data validation.


# Global Variables()

# Classes()

# Functions()


# Script Source: NanSense_0.0.1.py
# File name: script_documentation.txt
# Made by: docEngine (another SlicedPy Speciality Script)


import datetime
import pyodbc
import csv
import os
    

def GetColumns(TableName):
    
    cnxn = pyodbc.connect('DRIVER={ODBC Driver 13 for SQL Server};SERVER=OPTSQL01;DATABASE=NGProd;Trusted_Connection=yes;')
    cursor = cnxn.cursor()


    GetHeader = cursor.execute('SELECT column_name FROM INFORMATION_Schema.columns where table_name=\''+TableName+'\' ORDER BY ORDINAL_POSITION ;').fetchall()
    TotalRows = cursor.execute('select count(*) from '+TableName).fetchall()[0][0]

   
    header = []
    possible_ids,possible_amts,possible_dts = [],[],[]

    print ("-"*30+" "+TableName+" "+"-"*30)
    print (" "*38+" COLUMN ASSESSMENT "+" "*38)
   
    for each in GetHeader:
        header.append(str(each[0]))

    for each in header:
        NullRows = int(cursor.execute('select count(*) from '+TableName+' where '+each+' is null').fetchall()[0][0])
        if TotalRows - NullRows != 0:
            if "_id" in each or "_nbr" in each:
                possible_ids.append(each)

            elif "_amt" in each:
                possible_amts.append(each)

            elif "_date" in each or "_timestamp" in each:
                possible_dts.append(each)
            else:
                print (each+",")
                
                
            

    print ("\n\n"+"-"*40+" Possible IDs"+"-"*40)
    for each in possible_ids:
        print(each)

    print ("\n\n"+"-"*40+" Possible AMTs"+"-"*40)
    for each in possible_amts:
        print(each)

    print ("\n\n"+"-"*40+" Possible Dates"+"-"*40)
    for each in possible_dts:
        print(each)
                
        


GetColumns("GeneratePaymentReportTempTable")
           
