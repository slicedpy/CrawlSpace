SELECT * FROM GenerateChargesReportTempTable;
SELECT column_name FROM INFORMATION_Schema.columns where table_name=\'GenerateChargesReportTempTable\' ORDER BY ORDINAL_POSITION ;